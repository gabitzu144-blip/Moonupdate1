# MoonCity Sisteme (Forge 1.20.1)

Include tot ce era in MoonCity X (truse, bandaje, NPC medic, config) + joburi, HUD, minimap, portbagaj cu kg.

## Compilare
1. JDK 17 + Gradle 8.1.1+ (sau import in IntelliJ ca proiect Gradle).
2. `gradle build` -> jar-ul apare in `build/libs/mooncitysisteme-1.0.0.jar`.
3. Pune-l in `mods/` impreuna cu MrCrayfish Vehicle + Framework. Merge si fara Vehicle (portbagajul cere un vehicul).

## Joburi (10): tirist, miner, fermier, pescar, taximetrist, curier, lemnar, medic, mecanic, sofer_autobuz
- `/mooncity job <id> spawn` sau scurt `/<id> spawn` (ex. `/miner spawn`) - OP.
- Click dreapta pe NPC: iei jobul, apoi iti da contract. Shift+click = anulare contract.
- NPC `medic`: click = trusa, Shift+click = bandaj (preturi in config).
- `/mooncity join <id>`, `/mooncity quit`, `/mooncity bani <jucator> <suma>`, `/mooncity reload`.

## Portbagaj: tasta B langa/in vehicul (orice entitate din modul `vehicle`)
Limita de kg per vehicul si greutatea fiecarui item se editeaza in `config/mooncitysisteme.json`.

## Config: `config/mooncitysisteme.json` (creat la prima pornire)
Preturi, vindecare, plata medic, tabele de plata/xp pe nivel pentru fiecare job, blocuri pentru miner/fermier/lemnar, sete, kg.

## GitHub
Dezarhiveaza zip-ul si urca CONTINUTUL (nu un folder in folder) in repo. La fiecare push, tab-ul **Actions** compileaza
singur jar-ul; il iei din **Artifacts -> mooncitysisteme-jar**.
