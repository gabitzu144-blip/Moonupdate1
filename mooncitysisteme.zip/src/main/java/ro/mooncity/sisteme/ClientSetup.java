package ro.mooncity.sisteme;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = MoonCitySisteme.ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {
    public static final KeyMapping TRUNK = new KeyMapping("key.mooncitysisteme.trunk",
            InputConstants.KEY_B, "key.categories.mooncitysisteme");

    @SubscribeEvent
    public static void keys(RegisterKeyMappingsEvent e) { e.register(TRUNK); }

    @SubscribeEvent
    public static void overlays(RegisterGuiOverlaysEvent e) {
        e.registerAboveAll("mooncity_hud", (gui, g, partial, w, h) -> Hud.render(g, w, h));
    }

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(ModEntities.JOB_NPC.get(), JobNpcRenderer::new);
    }
}
