package ro.mooncity.sisteme;

import net.minecraft.client.model.VillagerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class JobNpcRenderer extends MobRenderer<JobNpc, VillagerModel<JobNpc>> {
    private static final ResourceLocation TEX = new ResourceLocation("textures/entity/villager/villager.png");

    public JobNpcRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new VillagerModel<>(ctx.bakeLayer(ModelLayers.VILLAGER)), 0.5f);
    }

    @Override
    public ResourceLocation getTextureLocation(JobNpc npc) { return TEX; }
}
