package ro.mooncity.sisteme;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class Net {
    private static final String V = "1";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(MoonCitySisteme.ID, "main"), () -> V, V::equals, V::equals);
    private static final Map<UUID, SyncPacket> LAST = new HashMap<>();

    public static void init() {
        CH.registerMessage(0, SyncPacket.class, SyncPacket::write, SyncPacket::read, (m, c) -> {
            c.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> Hud.state = m));
            c.get().setPacketHandled(true);
        });
        CH.registerMessage(1, OpenTrunk.class, (m, b) -> { }, b -> new OpenTrunk(), (m, c) -> {
            ServerPlayer p = c.get().getSender();
            c.get().enqueueWork(() -> { if (p != null) Trunk.open(p); });
            c.get().setPacketHandled(true);
        });
    }

    /** Trimite doar daca s-a schimbat ceva (sau force). */
    public static void sync(ServerPlayer p, boolean force) {
        SyncPacket now = PlayerData.packet(p);
        if (!force && now.equals(LAST.get(p.getUUID()))) return;
        LAST.put(p.getUUID(), now);
        CH.send(PacketDistributor.PLAYER.with(() -> p), now);
    }

    public static void forget(UUID id) { LAST.remove(id); }
}
