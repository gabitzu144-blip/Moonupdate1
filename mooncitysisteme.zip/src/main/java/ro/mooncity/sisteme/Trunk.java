package ro.mooncity.sisteme;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraftforge.network.NetworkHooks;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** Portbagaj pentru orice vehicul din modul "vehicle" (MrCrayfish), cu limita de kg din config. */
public class Trunk {

    public static boolean isVehicle(Entity e) {
        ResourceLocation k = ForgeRegistries.ENTITY_TYPES.getKey(e.getType());
        return k != null && k.getNamespace().equals("vehicle");
    }

    public static double itemKg(ItemStack s) {
        ResourceLocation k = ForgeRegistries.ITEMS.getKey(s.getItem());
        Double d = k == null ? null : MoonConfig.data.itemKg.get(k.toString());
        return d != null ? d : MoonConfig.data.defaultItemKg;
    }

    public static double weight(Container c) {
        double w = 0;
        for (int i = 0; i < c.getContainerSize(); i++) {
            ItemStack s = c.getItem(i);
            if (!s.isEmpty()) w += itemKg(s) * s.getCount();
        }
        return w;
    }

    public static double maxKg(Entity v) {
        ResourceLocation k = ForgeRegistries.ENTITY_TYPES.getKey(v.getType());
        if (k == null) return MoonConfig.data.defaultTrunkKg;
        return MoonConfig.data.trunkKg.getOrDefault(k.getPath(), MoonConfig.data.defaultTrunkKg);
    }

    public static String kg(double d) { return String.format(Locale.ROOT, "%.1f", d); }

    public static void open(ServerPlayer p) {
        Entity veh = null;
        if (p.getVehicle() != null && isVehicle(p.getVehicle())) {
            veh = p.getVehicle();
        } else {
            double best = Double.MAX_VALUE;
            for (Entity e : p.level().getEntities(p, p.getBoundingBox().inflate(4), Trunk::isVehicle)) {
                double dist = e.distanceToSqr(p);
                if (dist < best) { best = dist; veh = e; }
            }
        }
        if (veh == null) {
            p.displayClientMessage(Component.literal("Nu e niciun vehicul in apropiere."), true);
            return;
        }
        final Entity vehicle = veh;
        double max = maxKg(vehicle);
        SimpleContainer box = Data.get(p).box(vehicle.getUUID());
        Component title = Component.literal("Portbagaj  " + kg(weight(box)) + " / " + kg(max) + " kg");
        NetworkHooks.openScreen(p, new SimpleMenuProvider(
                (id, inv, pl) -> new TrunkMenu(id, inv, box, vehicle, max), title));
    }

    /** Continutul portbagajelor, salvat in lume dupa UUID-ul vehiculului. */
    public static class Data extends SavedData {
        private final Map<UUID, SimpleContainer> boxes = new HashMap<>();

        public static Data get(ServerPlayer p) {
            return p.getServer().overworld().getDataStorage()
                    .computeIfAbsent(Data::load, Data::new, "mooncity_trunks");
        }

        public SimpleContainer box(UUID id) {
            return boxes.computeIfAbsent(id, k -> {
                SimpleContainer c = new SimpleContainer(27);
                c.addListener(x -> setDirty());
                return c;
            });
        }

        public static Data load(CompoundTag tag) {
            Data d = new Data();
            CompoundTag all = tag.getCompound("boxes");
            for (String k : all.getAllKeys()) {
                try {
                    SimpleContainer c = new SimpleContainer(27);
                    c.fromTag(all.getList(k, 10));
                    c.addListener(x -> d.setDirty());
                    d.boxes.put(UUID.fromString(k), c);
                } catch (IllegalArgumentException ignored) { }
            }
            return d;
        }

        @Override
        public CompoundTag save(CompoundTag tag) {
            CompoundTag all = new CompoundTag();
            for (Map.Entry<UUID, SimpleContainer> en : boxes.entrySet())
                all.put(en.getKey().toString(), en.getValue().createTag());
            tag.put("boxes", all);
            return tag;
        }
    }
}
