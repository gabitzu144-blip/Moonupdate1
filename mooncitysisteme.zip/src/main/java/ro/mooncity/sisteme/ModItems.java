package ro.mooncity.sisteme;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MoonCitySisteme.ID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MoonCitySisteme.ID);

    public static final RegistryObject<Item> MEDKIT = ITEMS.register("medkit",
            () -> new MedkitItem(() -> MoonConfig.data.medkitHeal, new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> BANDAGE = ITEMS.register("bandage",
            () -> new MedkitItem(() -> MoonConfig.data.bandageHeal, new Item.Properties().stacksTo(32)));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.mooncitysisteme"))
                    .icon(() -> new ItemStack(MEDKIT.get()))
                    .displayItems((params, out) -> { out.accept(MEDKIT.get()); out.accept(BANDAGE.get()); })
                    .build());
}
