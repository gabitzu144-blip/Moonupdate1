package ro.mooncity.sisteme;

import net.minecraft.network.chat.Component;
import net.minecraft.world.Container;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ItemStack;

/** Meniu de lada 9x3. Daca depasesti kg-urile, surplusul ti se intoarce in inventar. */
public class TrunkMenu extends ChestMenu {
    private final Container box;
    private final Entity vehicle;
    private final double max;

    public TrunkMenu(int id, Inventory inv, Container box, Entity vehicle, double max) {
        super(MenuType.GENERIC_9x3, id, inv, box, 3);
        this.box = box;
        this.vehicle = vehicle;
        this.max = max;
    }

    @Override
    public void clicked(int slot, int button, ClickType type, Player player) {
        super.clicked(slot, button, type, player);
        if (player.level().isClientSide) return;
        double w = Trunk.weight(box);
        if (w <= max) return;
        for (int i = box.getContainerSize() - 1; i >= 0 && w > max; i--) {
            ItemStack s = box.getItem(i);
            if (s.isEmpty()) continue;
            double each = Math.max(0.01, Trunk.itemKg(s));
            int excess = Math.min(s.getCount(), (int) Math.ceil((w - max) / each));
            ItemStack back = s.copy();
            back.setCount(excess);
            s.shrink(excess);
            if (s.isEmpty()) box.setItem(i, ItemStack.EMPTY);
            player.getInventory().placeItemBackInInventory(back);
            w = Trunk.weight(box);
        }
        box.setChanged();
        player.displayClientMessage(Component.literal("Portbagaj plin! Limita: " + Trunk.kg(max) + " kg"), true);
    }

    @Override
    public boolean stillValid(Player player) {
        return !vehicle.isRemoved() && vehicle.distanceToSqr(player) < 100;
    }
}
