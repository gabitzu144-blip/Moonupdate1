package ro.mooncity.sisteme;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.minecraftforge.fml.loading.FMLPaths;
import org.slf4j.Logger;
import com.mojang.logging.LogUtils;

import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/** config/mooncitysisteme.json - toate preturile, joburile si limitele de kg se modifica de aici. */
public class MoonConfig {
    private static final Logger LOG = LogUtils.getLogger();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static class Job {
        public String id, name, kind;          // kind: delivery | break | fish | heal
        public boolean requiresVehicle;
        public int minDist = 80, maxDist = 400; // delivery
        public int goalMin = 1, goalMax = 1;    // break / fish
        public List<String> blocks = new ArrayList<>();
        public int[] xpTable = {0, 100, 250, 500, 1000}; // xp cumulat pentru nivelul i+1
        public int[] payTable = {100, 150, 220, 320, 450}; // plata pe nivel
        public int xpPerTask = 25;
    }

    public static class Data {
        public int startMoney = 500;
        public int medkitPrice = 250, bandagePrice = 60;
        public int medkitHeal = 12, bandageHeal = 4;   // puncte de viata (2 = o inima)
        public int medicPay = 80;                      // plata medicului per vindecare
        public double defaultTrunkKg = 40;
        public double defaultItemKg = 0.5;
        public Map<String, Double> trunkKg = new LinkedHashMap<>(); // id entitate vehicle -> kg max
        public Map<String, Double> itemKg = new LinkedHashMap<>();  // id item -> kg
        public int thirstSeconds = 90;                 // secunde per punct de sete
        public List<Job> jobs = new ArrayList<>();
    }

    public static Data data = defaults();

    public static Job job(String id) {
        if (id == null) return null;
        for (Job j : data.jobs) if (j.id.equals(id)) return j;
        return null;
    }

    private static Job mk(String id, String name, String kind, boolean veh, int min, int max, int base, String... blocks) {
        Job j = new Job();
        j.id = id; j.name = name; j.kind = kind; j.requiresVehicle = veh;
        j.minDist = min; j.maxDist = max;
        double[] m = {1, 1.4, 2, 2.8, 4};
        j.payTable = new int[5];
        for (int i = 0; i < 5; i++) j.payTable[i] = (int) Math.round(base * m[i]);
        j.blocks = new ArrayList<>(Arrays.asList(blocks));
        return j;
    }

    private static Data defaults() {
        Data d = new Data();
        d.trunkKg.put("mini_bus", 120.0);
        d.trunkKg.put("tractor", 80.0);
        d.trunkKg.put("off_roader", 100.0);
        d.trunkKg.put("storage_trailer", 200.0);
        d.itemKg.put("minecraft:iron_ingot", 1.0);
        d.itemKg.put("minecraft:gold_ingot", 1.5);
        d.itemKg.put("minecraft:diamond", 0.8);
        d.itemKg.put("minecraft:cobblestone", 1.5);
        d.itemKg.put("minecraft:stone", 1.5);
        d.itemKg.put("minecraft:iron_block", 9.0);

        d.jobs.add(mk("tirist", "Tirist", "delivery", true, 200, 700, 600));
        Job miner = mk("miner", "Miner", "break", false, 0, 0, 400,
                "minecraft:stone", "minecraft:deepslate", "minecraft:coal_ore", "minecraft:iron_ore",
                "minecraft:copper_ore", "minecraft:gold_ore", "minecraft:deepslate_coal_ore",
                "minecraft:deepslate_iron_ore", "minecraft:deepslate_copper_ore", "minecraft:deepslate_gold_ore",
                "minecraft:diamond_ore", "minecraft:deepslate_diamond_ore");
        miner.goalMin = 30; miner.goalMax = 60;
        d.jobs.add(miner);
        Job farm = mk("fermier", "Fermier", "break", false, 0, 0, 300,
                "minecraft:wheat", "minecraft:carrots", "minecraft:potatoes", "minecraft:beetroots");
        farm.goalMin = 30; farm.goalMax = 60;
        d.jobs.add(farm);
        Job fish = mk("pescar", "Pescar", "fish", false, 0, 0, 350);
        fish.goalMin = 5; fish.goalMax = 10;
        d.jobs.add(fish);
        d.jobs.add(mk("taximetrist", "Taximetrist", "delivery", true, 80, 300, 250));
        d.jobs.add(mk("curier", "Curier", "delivery", false, 100, 300, 200));
        Job wood = mk("lemnar", "Lemnar", "break", false, 0, 0, 350,
                "minecraft:oak_log", "minecraft:birch_log", "minecraft:spruce_log", "minecraft:jungle_log",
                "minecraft:acacia_log", "minecraft:dark_oak_log");
        wood.goalMin = 20; wood.goalMax = 40;
        d.jobs.add(wood);
        d.jobs.add(mk("medic", "Medic", "heal", false, 0, 0, 80));
        d.jobs.add(mk("mecanic", "Mecanic", "delivery", false, 100, 350, 280));
        d.jobs.add(mk("sofer_autobuz", "Șofer de autobuz", "delivery", true, 150, 500, 450));
        return d;
    }

    public static void load() {
        Path p = FMLPaths.CONFIGDIR.get().resolve("mooncitysisteme.json");
        try {
            if (Files.exists(p)) {
                try (Reader r = Files.newBufferedReader(p, StandardCharsets.UTF_8)) {
                    Data loaded = GSON.fromJson(r, Data.class);
                    if (loaded != null && loaded.jobs != null && !loaded.jobs.isEmpty()) {
                        data = loaded;
                        return;
                    }
                }
            }
            data = defaults();
            try (Writer w = Files.newBufferedWriter(p, StandardCharsets.UTF_8)) {
                GSON.toJson(data, w);
            }
        } catch (Exception ex) {
            LOG.error("[MoonCity] Config invalid, folosesc valorile implicite", ex);
            data = defaults();
        }
    }
}
