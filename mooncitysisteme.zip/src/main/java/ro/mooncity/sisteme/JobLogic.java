package ro.mooncity.sisteme;

import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
import net.minecraftforge.event.entity.player.ItemFishedEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

@Mod.EventBusSubscriber(modid = MoonCitySisteme.ID)
public class JobLogic {

    // ---------- interactiune NPC ----------
    public static void interact(ServerPlayer p, JobNpc npc) {
        MoonConfig.Job j = MoonConfig.job(npc.getJob());
        if (j == null) return;
        CompoundTag t = PlayerData.tag(p);

        if (j.kind.equals("heal")) { // NPC Medic: magazin (shift = bandaj)
            boolean band = p.isShiftKeyDown();
            int price = band ? MoonConfig.data.bandagePrice : MoonConfig.data.medkitPrice;
            if (PlayerData.money(p) < price) {
                p.sendSystemMessage(Component.literal("Nu ai destui bani (" + price + " lei).").withStyle(ChatFormatting.RED));
                return;
            }
            PlayerData.addMoney(p, -price);
            ItemStack s = new ItemStack(band ? ModItems.BANDAGE.get() : ModItems.MEDKIT.get());
            if (!p.getInventory().add(s)) p.drop(s, false);
            p.sendSystemMessage(Component.literal("Ai cumparat " + (band ? "un bandaj" : "o trusa medicala")
                    + " cu " + price + " lei. (Shift = bandaj)").withStyle(ChatFormatting.GREEN));
            Net.sync(p, true);
            return;
        }

        if (!PlayerData.job(p).equals(j.id)) { join(p, j.id); return; }
        if (!t.getBoolean("has")) { createContract(p, j); return; }
        if (p.isShiftKeyDown()) {
            t.putBoolean("has", false);
            p.sendSystemMessage(Component.literal("Contract anulat.").withStyle(ChatFormatting.GRAY));
            Net.sync(p, true);
        } else {
            p.sendSystemMessage(Component.literal("Ai deja un contract activ. (Shift + click = anulare)").withStyle(ChatFormatting.YELLOW));
        }
    }

    public static void join(ServerPlayer p, String id) {
        MoonConfig.Job j = MoonConfig.job(id);
        if (j == null) return;
        CompoundTag t = PlayerData.tag(p);
        if (!t.getString("job").equals(id)) t.putInt("xp", 0);
        t.putString("job", id);
        t.putBoolean("has", false);
        p.sendSystemMessage(Component.literal("Ai devenit " + j.name + ".").withStyle(ChatFormatting.AQUA));
        Net.sync(p, true);
    }

    public static void quit(ServerPlayer p) {
        CompoundTag t = PlayerData.tag(p);
        t.putString("job", "");
        t.putBoolean("has", false);
        Net.sync(p, true);
    }

    static void title(ServerPlayer p, String main, String sub) {
        p.connection.send(new ClientboundSetTitlesAnimationPacket(5, 40, 10));
        if (sub != null) p.connection.send(new ClientboundSetSubtitleTextPacket(Component.literal(sub)));
        p.connection.send(new ClientboundSetTitleTextPacket(Component.literal(main).withStyle(ChatFormatting.GOLD)));
    }

    static void createContract(ServerPlayer p, MoonConfig.Job j) {
        CompoundTag t = PlayerData.tag(p);
        RandomSource r = p.getRandom();
        int lv = PlayerData.level(j, t.getInt("xp"));
        int pay = PlayerData.pay(j, lv);
        pay += r.nextInt(Math.max(1, pay / 10));
        t.putBoolean("has", true);
        t.putInt("reward", pay);
        t.putInt("progress", 0);
        String sub;
        if (j.kind.equals("delivery")) {
            double a = r.nextDouble() * Math.PI * 2;
            double d = j.minDist + r.nextDouble() * Math.max(1, j.maxDist - j.minDist);
            t.putInt("dx", (int) (p.getX() + Math.cos(a) * d));
            t.putInt("dz", (int) (p.getZ() + Math.sin(a) * d));
            t.putInt("goal", 0);
            sub = "Mergi la punctul marcat pe harta (" + (int) d + " m)";
        } else {
            t.putInt("goal", j.goalMin + r.nextInt(Math.max(1, j.goalMax - j.goalMin + 1)));
            sub = j.kind.equals("fish") ? "Pescuieste " + t.getInt("goal") + " pesti" : "Fa " + t.getInt("goal") + " bucati";
        }
        title(p, "CONTRACT NOU", sub + " | " + pay + " lei");
        Net.sync(p, true);
    }

    static void complete(ServerPlayer p, MoonConfig.Job j) {
        CompoundTag t = PlayerData.tag(p);
        int reward = t.getInt("reward");
        int oldLv = PlayerData.level(j, t.getInt("xp"));
        PlayerData.addMoney(p, reward);
        t.putInt("xp", t.getInt("xp") + j.xpPerTask);
        t.putBoolean("has", false);
        t.putInt("deliveries", t.getInt("deliveries") + 1);
        int newLv = PlayerData.level(j, t.getInt("xp"));
        title(p, j.kind.equals("delivery") ? "LIVRARE REUȘITĂ!" : "CONTRACT FINALIZAT!", "+" + reward + " lei");
        if (newLv > oldLv) p.sendSystemMessage(Component.literal("Felicitari! Ai ajuns la nivelul " + newLv + ".").withStyle(ChatFormatting.GOLD));
        Net.sync(p, true);
    }

    public static void paidHeal(ServerPlayer medic) {
        MoonConfig.Job j = MoonConfig.job(PlayerData.job(medic));
        if (j == null || !j.kind.equals("heal")) return;
        CompoundTag t = PlayerData.tag(medic);
        int lv = PlayerData.level(j, t.getInt("xp"));
        int pay = MoonConfig.data.medicPay + PlayerData.pay(j, lv) - PlayerData.pay(j, 1);
        PlayerData.addMoney(medic, pay);
        t.putInt("xp", t.getInt("xp") + 5);
        medic.displayClientMessage(Component.literal("+" + pay + " lei (vindecare)").withStyle(ChatFormatting.GREEN), true);
        Net.sync(medic, true);
    }

    // ---------- evenimente ----------
    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        CompoundTag t = PlayerData.tag(p);
        if (!t.getBoolean("init")) {
            t.putBoolean("init", true);
            t.putLong("money", MoonConfig.data.startMoney);
            t.putInt("thirst", 100);
        }
        Net.sync(p, true);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) { Net.forget(e.getEntity().getUUID()); }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        CompoundTag old = PlayerData.tag(e.getOriginal()).copy();
        CompoundTag now = PlayerData.tag(e.getEntity());
        for (String k : old.getAllKeys()) now.put(k, old.get(k));
        if (e.isWasDeath()) now.putInt("thirst", 100);
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) Net.sync(p, true);
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p)) return;
        if (p.tickCount % 20 != 0) return; // 1x pe secunda - nimic greu in tick
        CompoundTag t = PlayerData.tag(p);

        // sete
        int timer = t.getInt("thirstTimer") + 1;
        if (timer >= Math.max(10, MoonConfig.data.thirstSeconds)) {
            timer = 0;
            t.putInt("thirst", Math.max(0, t.getInt("thirst") - 1));
        }
        t.putInt("thirstTimer", timer);
        if (t.getInt("thirst") <= 0 && p.tickCount % 80 == 0 && !p.isCreative() && !p.isSpectator()) {
            p.hurt(p.damageSources().starve(), 1f);
        }

        // livrare
        if (t.getBoolean("has")) {
            MoonConfig.Job j = MoonConfig.job(t.getString("job"));
            if (j != null && j.kind.equals("delivery")) {
                double dx = p.getX() - (t.getInt("dx") + 0.5), dz = p.getZ() - (t.getInt("dz") + 0.5);
                boolean near = dx * dx + dz * dz < 36;
                if (near) {
                    boolean veh = p.getVehicle() != null && Trunk.isVehicle(p.getVehicle());
                    if (!j.requiresVehicle || veh) complete(p, j);
                    else if (p.tickCount % 100 == 0)
                        p.displayClientMessage(Component.literal("Trebuie sa fii intr-un vehicul!").withStyle(ChatFormatting.RED), true);
                }
            }
        }
        Net.sync(p, false);
    }

    @SubscribeEvent
    public static void onBreak(BlockEvent.BreakEvent e) {
        if (!(e.getPlayer() instanceof ServerPlayer p)) return;
        CompoundTag t = PlayerData.tag(p);
        if (!t.getBoolean("has")) return;
        MoonConfig.Job j = MoonConfig.job(t.getString("job"));
        if (j == null || !j.kind.equals("break")) return;
        var key = ForgeRegistries.BLOCKS.getKey(e.getState().getBlock());
        if (key == null || !j.blocks.contains(key.toString())) return;
        progress(p, j, t);
    }

    @SubscribeEvent
    public static void onFish(ItemFishedEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        CompoundTag t = PlayerData.tag(p);
        if (!t.getBoolean("has")) return;
        MoonConfig.Job j = MoonConfig.job(t.getString("job"));
        if (j == null || !j.kind.equals("fish")) return;
        progress(p, j, t);
    }

    private static void progress(ServerPlayer p, MoonConfig.Job j, CompoundTag t) {
        int pr = t.getInt("progress") + 1;
        t.putInt("progress", pr);
        if (pr >= t.getInt("goal")) complete(p, j);
        else Net.sync(p, false);
    }

    @SubscribeEvent
    public static void onDrink(LivingEntityUseItemEvent.Finish e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        ItemStack s = e.getItem();
        int add = 0;
        if (s.is(Items.POTION)) add = 35;
        else if (s.is(Items.MILK_BUCKET)) add = 40;
        else if (s.is(Items.MELON_SLICE)) add = 8;
        if (add > 0) {
            CompoundTag t = PlayerData.tag(p);
            t.putInt("thirst", Math.min(100, t.getInt("thirst") + add));
            Net.sync(p, false);
        }
    }

    // ---------- comenzi ----------
    private static final com.mojang.brigadier.suggestion.SuggestionProvider<CommandSourceStack> JOBS =
            (c, b) -> SharedSuggestionProvider.suggest(MoonConfig.data.jobs.stream().map(x -> x.id), b);

    private static int spawn(CommandContext<CommandSourceStack> c, String id) throws CommandSyntaxException {
        MoonConfig.Job j = MoonConfig.job(id);
        if (j == null) {
            c.getSource().sendFailure(Component.literal("Job necunoscut: " + id));
            return 0;
        }
        ServerPlayer p = c.getSource().getPlayerOrException();
        ServerLevel lvl = p.serverLevel();
        JobNpc npc = ModEntities.JOB_NPC.get().create(lvl);
        if (npc == null) return 0;
        npc.moveTo(p.getX(), p.getY(), p.getZ(), p.getYRot() + 180f, 0f);
        npc.setJob(id);
        lvl.addFreshEntity(npc);
        c.getSource().sendSuccess(() -> Component.literal("NPC " + j.name + " creat."), true);
        return 1;
    }

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) {
        var d = e.getDispatcher();
        var root = Commands.literal("mooncity")
                .then(Commands.literal("job").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("id", StringArgumentType.word()).suggests(JOBS)
                                .then(Commands.literal("spawn").executes(c -> spawn(c, StringArgumentType.getString(c, "id"))))))
                .then(Commands.literal("join")
                        .then(Commands.argument("id", StringArgumentType.word()).suggests(JOBS)
                                .executes(c -> {
                                    String id = StringArgumentType.getString(c, "id");
                                    if (MoonConfig.job(id) == null) return 0;
                                    join(c.getSource().getPlayerOrException(), id);
                                    return 1;
                                })))
                .then(Commands.literal("quit").executes(c -> { quit(c.getSource().getPlayerOrException()); return 1; }))
                .then(Commands.literal("bani").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("jucator", EntityArgument.player())
                                .then(Commands.argument("suma", LongArgumentType.longArg())
                                        .executes(c -> {
                                            ServerPlayer t = EntityArgument.getPlayer(c, "jucator");
                                            PlayerData.addMoney(t, LongArgumentType.getLong(c, "suma"));
                                            Net.sync(t, true);
                                            return 1;
                                        }))))
                .then(Commands.literal("reload").requires(s -> s.hasPermission(2))
                        .executes(c -> {
                            MoonConfig.load();
                            c.getSource().sendSuccess(() -> Component.literal("Config reincarcat (comenzile /<job> spawn noi cer restart)."), true);
                            return 1;
                        }));
        d.register(root);
        // scurtatura: /<job> spawn  (ex: /miner spawn)
        for (MoonConfig.Job j : MoonConfig.data.jobs) {
            final String id = j.id;
            if (id.equals("mooncity")) continue;
            d.register(Commands.literal(id).requires(s -> s.hasPermission(2))
                    .then(Commands.literal("spawn").executes(c -> spawn(c, id))));
        }
    }
}
