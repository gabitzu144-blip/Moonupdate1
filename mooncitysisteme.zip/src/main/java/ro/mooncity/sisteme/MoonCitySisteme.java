package ro.mooncity.sisteme;

import net.minecraft.world.entity.EntityType;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(MoonCitySisteme.ID)
public class MoonCitySisteme {
    public static final String ID = "mooncitysisteme";

    public MoonCitySisteme() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        MoonConfig.load();
        ModItems.ITEMS.register(bus);
        ModItems.TABS.register(bus);
        ModEntities.ENTITIES.register(bus);
        bus.addListener(this::attributes);
        Net.init();
    }

    private void attributes(EntityAttributeCreationEvent e) {
        e.put(ModEntities.JOB_NPC.get(), JobNpc.attrs().build());
    }
}
