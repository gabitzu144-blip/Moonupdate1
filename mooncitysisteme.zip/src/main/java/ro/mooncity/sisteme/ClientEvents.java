package ro.mooncity.sisteme;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.blockentity.BeaconRenderer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = MoonCitySisteme.ID, value = Dist.CLIENT)
public class ClientEvents {

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        Hud.clientTick(mc);
        while (ClientSetup.TRUNK.consumeClick()) {
            if (mc.player != null) Net.CH.sendToServer(new OpenTrunk());
        }
    }

    /** HUD-ul MoonCity inlocuieste inimile / armura / mancarea din vanilla. */
    @SubscribeEvent
    public static void overlay(RenderGuiOverlayEvent.Pre e) {
        var id = e.getOverlay().id();
        if (id.equals(VanillaGuiOverlay.PLAYER_HEALTH.id()) || id.equals(VanillaGuiOverlay.ARMOR_LEVEL.id())
                || id.equals(VanillaGuiOverlay.FOOD_LEVEL.id())) e.setCanceled(true);
    }

    /** Fascicul de lumina la destinatia contractului de livrare. */
    @SubscribeEvent
    public static void level(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;
        SyncPacket s = Hud.state;
        Minecraft mc = Minecraft.getInstance();
        if (s == null || !s.has() || !s.kind().equals("delivery") || mc.level == null || mc.player == null) return;
        PoseStack ps = e.getPoseStack();
        Vec3 cam = e.getCamera().getPosition();
        ps.pushPose();
        ps.translate(s.dx() + 0.5 - cam.x, mc.player.getY() - 40 - cam.y, s.dz() + 0.5 - cam.z);
        var bs = mc.renderBuffers().bufferSource();
        BeaconRenderer.renderBeaconBeam(ps, bs, BeaconRenderer.BEAM_LOCATION, e.getPartialTick(), 1f,
                mc.level.getGameTime(), 0, 320, new float[]{0.3f, 0.8f, 1f}, 0.2f, 0.25f);
        bs.endBatch();
        ps.popPose();
    }
}
