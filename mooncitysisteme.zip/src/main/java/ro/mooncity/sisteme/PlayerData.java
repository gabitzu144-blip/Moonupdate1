package ro.mooncity.sisteme;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;

public final class PlayerData {
    private PlayerData() { }

    public static CompoundTag tag(Player p) {
        CompoundTag root = p.getPersistentData();
        if (!root.contains(Player.PERSISTED_NBT_TAG, 10)) root.put(Player.PERSISTED_NBT_TAG, new CompoundTag());
        CompoundTag persisted = root.getCompound(Player.PERSISTED_NBT_TAG);
        if (!persisted.contains("mooncity", 10)) persisted.put("mooncity", new CompoundTag());
        return persisted.getCompound("mooncity");
    }

    public static long money(Player p) { return tag(p).getLong("money"); }

    public static void addMoney(Player p, long amount) {
        CompoundTag t = tag(p);
        t.putLong("money", Math.max(0, t.getLong("money") + amount));
    }

    public static String job(Player p) { return tag(p).getString("job"); }

    public static int level(MoonConfig.Job j, int xp) {
        int lv = 1;
        for (int i = 0; i < j.xpTable.length; i++) if (xp >= j.xpTable[i]) lv = i + 1;
        return lv;
    }

    public static int pay(MoonConfig.Job j, int level) {
        int i = Math.max(0, Math.min(level, j.payTable.length) - 1);
        return j.payTable[i];
    }

    public static SyncPacket packet(Player p) {
        CompoundTag t = tag(p);
        MoonConfig.Job j = MoonConfig.job(t.getString("job"));
        int xp = t.getInt("xp");
        int lv = 0, next = 0;
        String name = "", kind = "";
        if (j != null) {
            name = j.name; kind = j.kind;
            lv = level(j, xp);
            next = lv < j.xpTable.length ? j.xpTable[lv] : xp;
        }
        return new SyncPacket(t.getLong("money"), name, kind, lv, xp, next, t.getBoolean("has"),
                t.getInt("dx"), t.getInt("dz"), t.getInt("progress"), t.getInt("goal"),
                t.getInt("reward"), t.getInt("thirst"));
    }
}
