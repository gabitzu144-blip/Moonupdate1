package ro.mooncity.sisteme;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import java.util.function.IntSupplier;

/** Click dreapta = te vindeci. Click pe alt jucator = il vindeci (medicii primesc plata). */
public class MedkitItem extends Item {
    private final IntSupplier heal;

    public MedkitItem(IntSupplier heal, Properties props) {
        super(props);
        this.heal = heal;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.getHealth() >= player.getMaxHealth()) return InteractionResultHolder.fail(stack);
        if (!level.isClientSide) {
            player.heal(heal.getAsInt());
            if (!player.getAbilities().instabuild) stack.shrink(1);
            player.getCooldowns().addCooldown(this, 30);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (!(target instanceof Player other)) return InteractionResult.PASS;
        if (other.getHealth() >= other.getMaxHealth()) return InteractionResult.FAIL;
        if (!player.level().isClientSide) {
            other.heal(heal.getAsInt());
            if (!player.getAbilities().instabuild) stack.shrink(1);
            player.getCooldowns().addCooldown(this, 30);
            if (player instanceof ServerPlayer sp) JobLogic.paidHeal(sp);
        }
        return InteractionResult.sidedSuccess(player.level().isClientSide);
    }
}
