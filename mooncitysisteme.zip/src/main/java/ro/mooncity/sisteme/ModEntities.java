package ro.mooncity.sisteme;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MoonCitySisteme.ID);

    public static final RegistryObject<EntityType<JobNpc>> JOB_NPC = ENTITIES.register("job_npc",
            () -> EntityType.Builder.<JobNpc>of(JobNpc::new, MobCategory.MISC)
                    .sized(0.6f, 1.95f).clientTrackingRange(8).build("job_npc"));
}
