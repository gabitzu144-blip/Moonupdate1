package ro.mooncity.sisteme;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.Vec3;

/** HUD MoonCity: logo, bani, job, minimap, viata/armura/mancare/apa, vitezometru. Fara alocari per frame. */
public class Hud {
    private static final ResourceLocation LOGO = new ResourceLocation(MoonCitySisteme.ID, "textures/gui/logo.png");
    public static volatile SyncPacket state;

    private static DynamicTexture mapTex;
    private static ResourceLocation mapLoc;
    private static double speed;
    private static Vec3 lastPos;

    public static void clientTick(Minecraft mc) {
        if (mc.player == null || mc.level == null) return;
        Entity v = mc.player.getVehicle();
        if (v != null && Trunk.isVehicle(v)) {
            Vec3 p = v.position();
            if (lastPos != null) speed = speed * 0.7 + p.subtract(lastPos).horizontalDistance() * 20 * 3.6 * 0.3;
            lastPos = p;
        } else {
            speed = 0;
            lastPos = null;
        }
        if (mc.player.tickCount % 20 == 0) updateMap(mc);
    }

    /** 64x64 px, 1 px = 2 blocuri, doar din chunk-uri deja incarcate, 1x pe secunda. */
    private static void updateMap(Minecraft mc) {
        if (mapTex == null) {
            mapTex = new DynamicTexture(64, 64, true);
            mapLoc = mc.getTextureManager().register("mooncity_minimap", mapTex);
        }
        NativeImage img = mapTex.getPixels();
        if (img == null) return;
        int px = Mth.floor(mc.player.getX()), pz = Mth.floor(mc.player.getZ());
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int z = 0; z < 64; z++) {
            for (int x = 0; x < 64; x++) {
                int wx = px + (x - 32) * 2, wz = pz + (z - 32) * 2;
                int color = 0xFF202020;
                LevelChunk ch = mc.level.getChunkSource().getChunkNow(wx >> 4, wz >> 4);
                if (ch != null) {
                    int y = ch.getHeight(Heightmap.Types.WORLD_SURFACE, wx & 15, wz & 15);
                    m.set(wx, y - 1, wz);
                    color = ch.getBlockState(m).getMapColor(mc.level, m).calculateRGBColor(MapColor.Brightness.NORMAL);
                }
                img.setPixelRGBA(x, z, color);
            }
        }
        mapTex.upload();
    }

    public static void render(GuiGraphics g, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        Font f = mc.font;
        SyncPacket s = state;

        // --- logo + nume + bani (dreapta sus)
        g.blit(LOGO, w - 124, 4, 28, 28, 0, 0, 128, 128, 128, 128);
        g.drawString(f, "MOONCITY", w - 92, 8, 0xFFFFFFFF, true);
        g.drawString(f, "\u00a7e$ " + (s == null ? 0 : s.money()), w - 92, 19, 0xFFFFFFFF, true);

        // --- panou job
        if (s != null && !s.jobName().isEmpty()) {
            int x0 = w - 130, y0 = 36;
            g.fill(x0, y0, w - 4, y0 + 46, 0x99000000);
            g.drawString(f, "\u00a7b" + s.jobName().toUpperCase() + " \u00a77NIV " + s.level(), x0 + 4, y0 + 4, 0xFFFFFFFF, true);
            int span = Math.max(1, s.xpNext() - 0);
            float frac = s.xpNext() <= 0 ? 1f : Mth.clamp(s.xp() / (float) span, 0f, 1f);
            g.fill(x0 + 4, y0 + 15, x0 + 122, y0 + 18, 0x88FFFFFF);
            g.fill(x0 + 4, y0 + 15, x0 + 4 + (int) (118 * frac), y0 + 18, 0xFF55FFFF);
            String line;
            if (s.kind().equals("heal")) line = "Vindeca jucatori cu trusa";
            else if (!s.has()) line = "Vorbeste cu NPC-ul pt contract";
            else if (s.kind().equals("delivery")) line = "Livreaza la punctul marcat";
            else line = "Progres " + s.progress() + "/" + s.goal();
            g.drawString(f, line, x0 + 4, y0 + 24, 0xFFFFFFFF, true);
            if (s.has()) g.drawString(f, "\u00a7aPlata: " + s.reward() + " lei", x0 + 4, y0 + 34, 0xFFFFFFFF, true);
        }

        // --- distanta pana la destinatie (sus centru)
        if (s != null && s.has() && s.kind().equals("delivery")) {
            double dx = s.dx() + 0.5 - mc.player.getX(), dz = s.dz() + 0.5 - mc.player.getZ();
            String d = (int) Math.sqrt(dx * dx + dz * dz) + " m";
            int tw = f.width(d);
            g.fill(w / 2 - tw / 2 - 6, 4, w / 2 + tw / 2 + 6, 17, 0x99000000);
            g.drawString(f, "\u00a7b" + d, w / 2 - tw / 2, 7, 0xFFFFFFFF, true);
        }

        // --- minimap (stanga jos)
        int mx = 6, my = h - 108, ms = 80;
        if (mapLoc != null) {
            g.fill(mx - 2, my - 2, mx + ms + 2, my + ms + 2, 0xFFFFFFFF);
            g.blit(mapLoc, mx, my, ms, ms, 0, 0, 64, 64, 64, 64);
            g.fill(mx + ms / 2 - 1, my + ms / 2 - 1, mx + ms / 2 + 2, my + ms / 2 + 2, 0xFFFFFFFF);
            if (s != null && s.has() && s.kind().equals("delivery")) {
                double k = ms / 128.0; // 128 blocuri acoperite
                int ox = (int) Mth.clamp((s.dx() - mc.player.getX()) * k, -ms / 2 + 2, ms / 2 - 3);
                int oy = (int) Mth.clamp((s.dz() - mc.player.getZ()) * k, -ms / 2 + 2, ms / 2 - 3);
                g.fill(mx + ms / 2 + ox - 1, my + ms / 2 + oy - 1, mx + ms / 2 + ox + 2, my + ms / 2 + oy + 2, 0xFFFF3030);
            }
        }

        // --- viata / armura / mancare / apa
        float hp = mc.player.getHealth() / Math.max(1f, mc.player.getMaxHealth());
        float ar = Math.min(20, mc.player.getArmorValue()) / 20f;
        float fo = mc.player.getFoodData().getFoodLevel() / 20f;
        float wa = s == null ? 1f : s.thirst() / 100f;
        bar(g, f, 0, h, hp, 0xFFE03030, "\u2764");
        bar(g, f, 1, h, ar, 0xFF4A90E2, "A");
        bar(g, f, 2, h, fo, 0xFFE0912A, "F");
        bar(g, f, 3, h, wa, 0xFF30D5E0, "W");

        // --- vitezometru (cand esti in vehicul)
        if (lastPos != null) {
            g.pose().pushPose();
            g.pose().translate(w - 90, h - 40, 0);
            g.pose().scale(2f, 2f, 1f);
            g.drawString(f, "" + (int) speed, 0, 0, 0xFFFFFFFF, true);
            g.pose().popPose();
            g.drawString(f, "km/h", w - 40, h - 30, 0xFF55FFFF, true);
        }
    }

    private static void bar(GuiGraphics g, Font f, int i, int h, float frac, int color, String label) {
        int x = 6 + i * 21, y = h - 14;
        g.fill(x, y, x + 19, y + 5, 0xAA000000);
        g.fill(x, y, x + (int) (19 * Mth.clamp(frac, 0f, 1f)), y + 5, color);
        g.drawString(f, label, x + 7, y - 10, color, true);
    }
}
