package ro.mooncity.sisteme;

/** Cerere client -> server: deschide portbagajul vehiculului din apropiere. */
public record OpenTrunk() { }
