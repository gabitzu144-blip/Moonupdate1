package ro.mooncity.sisteme;

import net.minecraft.network.FriendlyByteBuf;

/** Starea trimisa spre client pentru HUD (max 1x pe secunda, doar daca s-a schimbat). */
public record SyncPacket(long money, String jobName, String kind, int level, int xp, int xpNext,
                         boolean has, int dx, int dz, int progress, int goal, int reward, int thirst) {

    public void write(FriendlyByteBuf b) {
        b.writeLong(money); b.writeUtf(jobName); b.writeUtf(kind);
        b.writeInt(level); b.writeInt(xp); b.writeInt(xpNext);
        b.writeBoolean(has); b.writeInt(dx); b.writeInt(dz);
        b.writeInt(progress); b.writeInt(goal); b.writeInt(reward); b.writeInt(thirst);
    }

    public static SyncPacket read(FriendlyByteBuf b) {
        return new SyncPacket(b.readLong(), b.readUtf(), b.readUtf(), b.readInt(), b.readInt(), b.readInt(),
                b.readBoolean(), b.readInt(), b.readInt(), b.readInt(), b.readInt(), b.readInt(), b.readInt());
    }
}
