MoonCity X (Forge 1.20.1)
Build: ./gradlew build   (sau GitHub Actions -> tab Actions -> Build)
Pune mooncityvehicles-1.0.0.jar in libs-in/ ca sa fie inclus in jarul final.
In mods/ raman: MrCrayfish Vehicle + Framework. Config: config/mooncityx.json
Taste K = telefon. Tab creative: "MoonCity X".
NECOMPILAT inca - trimite erorile de build ca sa le reparam.
