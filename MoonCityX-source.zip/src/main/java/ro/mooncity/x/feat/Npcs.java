package ro.mooncity.x.feat;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import ro.mooncity.x.*;

import java.util.Map;
import java.util.UUID;

public class Npcs {
    public static String title(String r) {
        return switch (r) {
            case "seller" -> "§6Cumpărător";
            case "banker" -> "§bBancher";
            case "jobs" -> "§aAgenție de joburi";
            case "driving" -> "§eȘcoala de șoferi";
            case "casino" -> "§cCazino";
            case "black" -> "§8Piața neagră";
            case "medic" -> "§fMedic";
            case "city" -> "§9Primărie";
            case "taxi" -> "§eMoonTaxi";
            case "news" -> "§dMoonNews";
            case "depozit" -> "§6Depozit";
            default -> "NPC";
        };
    }

    public static void open(ServerPlayer p, MoonNpc n) {
        switch (n.role()) {
            case "seller" -> sellMenu(p);
            case "banker" -> Bank.main(p);
            case "jobs" -> Jobs.menu(p);
            case "driving" -> School.menu(p);
            case "casino" -> Casino.menu(p);
            case "black" -> Contracts.black(p);
            case "medic" -> City.medMenu(p);
            case "city" -> City.cityMenu(p);
            case "taxi" -> Taxi.menu(p);
            case "news" -> Social.newsMenu(p);
            case "depozit" -> Cargo.menu(p);
            default -> Util.msg(p, "Salut!");
        }
    }

    public static void sellMenu(ServerPlayer p) {
        Ui u = Ui.of("§6Cumpărător – vinde marfă").line("§7Banii intră direct în contul tău bancar.");
        long total = 0;
        for (Map.Entry<String, Integer> e : Cfg.I.sell.entrySet()) {
            int c = Util.count(p, e.getKey());
            if (c <= 0) continue;
            var it = Util.item(e.getKey());
            String nm = it == null ? e.getKey() : new net.minecraft.world.item.ItemStack(it).getHoverName().getString();
            total += (long) c * e.getValue();
            u.btn(nm + " x" + c + " • " + e.getValue() + " RON/buc → vinde tot", "npc:sell", "i", e.getKey());
        }
        u.line("§7Total posibil: §a" + Util.fmt(total));
        if (total > 0) u.btn("§aVinde tot ce se poate", "npc:sellall");
        u.send(p);
    }

    public static void act(ServerPlayer p, String s, CompoundTag d) {
        UUID u = p.getUUID();
        if (s.equals("sell")) {
            String id = Util.str(d, "i");
            Integer pr = Cfg.I.sell.get(id);
            if (pr != null) {
                int c = Util.remove(p, id, Util.count(p, id));
                if (c > 0) { Bank.add(u, (long) c * pr, "Vânzare marfă"); Util.msg(p, "§aAi vândut pentru " + Util.fmt((long) c * pr)); }
            }
        } else if (s.equals("sellall")) {
            long t = 0;
            for (Map.Entry<String, Integer> e : Cfg.I.sell.entrySet()) {
                int c = Util.remove(p, e.getKey(), Util.count(p, e.getKey()));
                t += (long) c * e.getValue();
            }
            if (t > 0) { Bank.add(u, t, "Vânzare marfă"); Util.msg(p, "§aAi vândut pentru " + Util.fmt(t)); }
        }
        sellMenu(p);
    }
}
