package ro.mooncity.x.feat;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;
import ro.mooncity.x.*;

import java.util.*;

/** Portbagaj pentru vehiculele MrCrayfish/Immersive: iteme cu greutate, capacitate in kg dupa tipul vehiculului. */
public class Trunk {
    static final String KEY = "moon_trunk";

    public static String typeOf(Entity e) {
        var k = ForgeRegistries.ENTITY_TYPES.getKey(e.getType());
        return k == null ? "" : k.getPath();
    }

    public static double capacity(Entity e) {
        Integer c = Cfg.I.trunkKg.get(typeOf(e));
        return c != null ? c : Cfg.I.trunkDefaultKg;
    }

    public static ListTag raw(Entity e) {
        CompoundTag d = e.getPersistentData();
        if (!d.contains(KEY, Tag.TAG_LIST)) d.put(KEY, new ListTag());
        return d.getList(KEY, Tag.TAG_COMPOUND);
    }

    public static List<ItemStack> items(Entity e) {
        List<ItemStack> l = new ArrayList<>();
        ListTag t = raw(e);
        for (int i = 0; i < t.size(); i++) { ItemStack s = ItemStack.of(t.getCompound(i)); if (!s.isEmpty()) l.add(s); }
        return l;
    }

    static void save(Entity e, List<ItemStack> l) {
        ListTag t = new ListTag();
        for (ItemStack s : l) if (!s.isEmpty()) t.add(s.save(new CompoundTag()));
        e.getPersistentData().put(KEY, t);
    }

    public static double used(Entity e) {
        double w = 0;
        for (ItemStack s : items(e)) w += Weights.of(s);
        return w;
    }

    public static int count(Entity e, String id) {
        int n = 0;
        for (ItemStack s : items(e)) if (Util.key(s.getItem()).equals(id)) n += s.getCount();
        return n;
    }

    public static int remove(Entity e, String id, int n) {
        List<ItemStack> l = items(e);
        int left = n;
        for (ItemStack s : l) {
            if (left <= 0) break;
            if (!Util.key(s.getItem()).equals(id)) continue;
            int t = Math.min(left, s.getCount());
            s.shrink(t);
            left -= t;
        }
        save(e, l);
        return n - left;
    }

    /** Baga cat incape (dupa kg). Intoarce cate bucati au intrat. */
    public static int add(Entity e, ItemStack st) {
        double each = Weights.of(st.copyWithCount(1));
        double free = capacity(e) - used(e);
        int can = each <= 0 ? st.getCount() : (int) Math.floor(free / each + 1e-9);
        int n = Math.min(can, st.getCount());
        if (n <= 0) return 0;
        List<ItemStack> l = items(e);
        ItemStack put = st.copyWithCount(n);
        boolean merged = false;
        for (ItemStack s : l) {
            if (ItemStack.isSameItemSameTags(s, put) && s.getCount() + n <= s.getMaxStackSize()) { s.grow(n); merged = true; break; }
        }
        if (!merged) l.add(put);
        save(e, l);
        return n;
    }

    static boolean allowed(ServerPlayer p, Entity v) {
        UUID o = Util.owner(v);
        return o == null || o.equals(p.getUUID()) || Util.op(p);
    }

    static boolean protectedItem(ItemStack s) {
        String id = Util.key(s.getItem());
        return id.equals("mooncityx:phone") || id.equals("mooncityx:bank_card") || id.equals("mooncityx:id_card")
            || id.equals("mooncityx:license") || id.equals("mooncityx:mdt_tablet");
    }

    public static void open(ServerPlayer p) {
        Entity v = Util.nearestVehicle(p, 5);
        if (v == null) { Util.bar(p, "§cNu ești lângă un vehicul."); return; }
        menu(p, v);
    }

    public static void menu(ServerPlayer p, Entity v) {
        if (!allowed(p, v)) { Util.msg(p, "§cVehiculul aparține altcuiva."); return; }
        String vid = v.getUUID().toString();
        double cap = capacity(v), use = used(v);
        Ui u = Ui.of("§dPortbagaj §7– " + typeOf(v));
        u.line("§7Portbagaj: §f" + Weights.fmt(use) + "§7/§f" + (int) cap + " kg   §8|   §7Tu: §f" + Weights.fmt(Weights.total(p)) + "§7/§f" + (int) Cfg.I.carryKg + " kg");
        List<ItemStack> in = items(v);
        u.sep().line("§eÎn portbagaj:");
        if (in.isEmpty()) u.line("§8(gol)");
        for (int i = 0; i < in.size(); i++) {
            ItemStack s = in.get(i);
            CompoundTag d = new CompoundTag();
            d.putString("v", vid);
            d.putInt("i", i);
            u.btn("Scoate " + s.getHoverName().getString() + " x" + s.getCount() + " §7(" + Weights.fmt(Weights.of(s)) + " kg)", "trunk:take", d);
        }
        if (!in.isEmpty()) u.btn("§aScoate tot", "trunk:takeall", "v", vid);
        u.sep().line("§eDin inventarul tău:");
        Map<String, Integer> cnt = new LinkedHashMap<>();
        Map<String, ItemStack> ex = new HashMap<>();
        var inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (s.isEmpty() || protectedItem(s)) continue;
            String id = Util.key(s.getItem());
            cnt.merge(id, s.getCount(), Integer::sum);
            ex.putIfAbsent(id, s);
        }
        int shown = 0;
        for (var e : cnt.entrySet()) {
            if (shown++ >= 24) break;
            ItemStack s = ex.get(e.getKey());
            CompoundTag d = new CompoundTag();
            d.putString("v", vid);
            d.putString("id", e.getKey());
            u.btn("Bagă " + s.getHoverName().getString() + " x" + e.getValue() + " §7(" + Weights.fmt(Weights.of(s.copyWithCount(1)) * e.getValue()) + " kg)", "trunk:put", d);
        }
        if (!cnt.isEmpty()) u.btn("§aBagă tot", "trunk:putall", "v", vid);
        u.send(p);
    }

    static Entity find(ServerPlayer p, CompoundTag d) {
        try {
            Entity e = p.serverLevel().getEntity(UUID.fromString(Util.str(d, "v")));
            if (e != null && Util.isVehicle(e) && e.distanceTo(p) <= 8 && allowed(p, e)) return e;
        } catch (Exception ignored) { }
        return null;
    }

    public static void act(ServerPlayer p, String s, CompoundTag d) {
        if (s.equals("open")) { open(p); return; }
        Entity v = find(p, d);
        if (v == null) { Util.msg(p, "§cEști prea departe de vehicul."); return; }
        var inv = p.getInventory();
        switch (s) {
            case "take" -> {
                List<ItemStack> l = items(v);
                int i = d.getInt("i");
                if (i >= 0 && i < l.size()) {
                    ItemStack st = l.remove(i);
                    save(v, l);
                    Util.give(p, st);
                }
            }
            case "takeall" -> {
                List<ItemStack> l = items(v);
                save(v, new ArrayList<>());
                for (ItemStack st : l) Util.give(p, st);
            }
            case "put" -> putId(p, v, Util.str(d, "id"));
            case "putall" -> {
                Set<String> ids = new LinkedHashSet<>();
                for (int i = 0; i < inv.getContainerSize(); i++) { ItemStack st = inv.getItem(i); if (!st.isEmpty() && !protectedItem(st)) ids.add(Util.key(st.getItem())); }
                for (String id : ids) putId(p, v, id);
            }
            default -> { }
        }
        menu(p, v);
    }

    static void putId(ServerPlayer p, Entity v, String id) {
        var inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack st = inv.getItem(i);
            if (st.isEmpty() || protectedItem(st) || !Util.key(st.getItem()).equals(id)) continue;
            int n = add(v, st);
            if (n <= 0) { Util.bar(p, "§cPortbagajul e plin (kg)."); return; }
            st.shrink(n);
            if (st.getCount() > 0) { Util.bar(p, "§cPortbagajul e plin (kg)."); return; }
        }
    }
}
