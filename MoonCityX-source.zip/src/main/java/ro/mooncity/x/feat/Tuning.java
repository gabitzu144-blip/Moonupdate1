package ro.mooncity.x.feat;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import ro.mooncity.x.*;

import java.util.UUID;

/** MoonTuning: parchezi masina pe locul de tuning, se deschide panoul din dreapta (stil FiveM) cu motor / roti / culoare / stage. */
public class Tuning {
    static final String[] TIERS = {"iron", "gold", "diamond", "netherite"};
    static final long[] ENG_PRICE = {3000, 9000, 25000, 60000};
    static final String[] WHEELS = {"standard", "sports", "racing", "off_road", "all_terrain", "snow"};
    static final long[] WHEEL_PRICE = {800, 2500, 6000, 3000, 3500, 1800};
    static final int[] WHEEL_HND = {45, 62, 82, 55, 50, 40};
    static final long[] STAGE_PRICE = {6000, 18000, 45000};
    static final int[] COLORS = {0xE53935, 0x1E88E5, 0x43A047, 0xFDD835, 0xFB8C00, 0x8E24AA, 0x212121, 0xFAFAFA, 0x757575, 0x00ACC1, 0xF06292, 0x6D4C41};
    static final String[] COLOR_NAMES = {"Roșu", "Albastru", "Verde", "Galben", "Portocaliu", "Violet", "Negru", "Alb", "Gri", "Cyan", "Roz", "Maro"};

    static String engType(Entity v) {
        String k = Util.key(Veh.engine(v).getItem());
        if (k.contains("small")) return "small";
        if (k.contains("electric")) return "electric";
        return "large";
    }

    static int tierIdx(Entity v) {
        String k = Util.key(Veh.engine(v).getItem());
        for (int i = 0; i < TIERS.length; i++) if (k.contains(TIERS[i])) return i;
        return -1;
    }

    static Entity find(ServerPlayer p, BlockPos at) {
        Entity v = Util.nearestVehicleAt(p.serverLevel(), at, 4.5);
        return v != null && Veh.powered(v) ? v : null;
    }

    static CompoundTag opt(int cat, String name, long price, int spd, int acc, int hnd, int brk, String id) {
        CompoundTag o = new CompoundTag();
        o.putInt("cat", cat);
        o.putString("name", name);
        o.putLong("price", price);
        o.putInt("spd", spd);
        o.putInt("acc", acc);
        o.putInt("hnd", hnd);
        o.putInt("brk", brk);
        o.putString("id", id);
        return o;
    }

    public static void act(ServerPlayer p, String s, CompoundTag d) {
        BlockPos at = d.contains("pos") ? BlockPos.of(d.getLong("pos")) : p.blockPosition();
        if (s.equals("buy")) { buy(p, at, Util.str(d, "id")); }
        send(p, at);
    }

    static void send(ServerPlayer p, BlockPos at) {
        Entity v = find(p, at);
        if (v == null) { Util.msg(p, "§cParchează o mașină pe locul de tuning (maxim 4 blocuri)."); Net.close(p); return; }
        int ti = tierIdx(v), stage = v.getPersistentData().getInt("moon_stage");
        CompoundTag t = new CompoundTag();
        t.putLong("pos", at.asLong());
        t.putString("veh", v.getType().getDescription().getString());
        t.putLong("bank", Bank.bal(p.getUUID()));
        t.putInt("spd", 35 + Math.max(ti, 0) * 15 + stage * 8);
        t.putInt("acc", 30 + Math.max(ti, 0) * 15 + stage * 8);
        t.putInt("hnd", 55);
        t.putInt("brk", 50 + stage * 4);
        t.putInt("mod", Math.min(100, 20 + stage * 25 + Math.max(ti, 0) * 10));
        ListTag o = new ListTag();
        String et = engType(v);
        for (int i = 0; i < TIERS.length; i++)
            o.add(opt(0, TIERS[i].substring(0, 1).toUpperCase() + TIERS[i].substring(1) + " " + et + " engine", ENG_PRICE[i], 35 + i * 15, 30 + i * 15, 55, 50, "e:" + TIERS[i]));
        if (Veh.canWheels(v)) for (int i = 0; i < WHEELS.length; i++)
            o.add(opt(1, "Roți " + WHEELS[i].replace('_', ' '), WHEEL_PRICE[i], 40, 40, WHEEL_HND[i], 50 + i * 3, "w:" + WHEELS[i]));
        if (Veh.canColor(v)) for (int i = 0; i < COLORS.length; i++)
            o.add(opt(2, "Vopsea " + COLOR_NAMES[i], 400, 35, 30, 55, 50, "c:" + String.format("%06X", COLORS[i])));
        for (int i = 0; i < 3; i++)
            o.add(opt(3, "ECU Stage " + (i + 1) + " (+" + (i + 1) * 12 + "% viteză)", STAGE_PRICE[i], 50 + i * 14, 45 + i * 14, 55, 50, "s:" + (i + 1)));
        t.put("opts", o);
        Net.to(p, "tuning", t);
    }

    static long price(String id) {
        try {
            String[] a = id.split(":");
            return switch (a[0]) {
                case "e" -> ENG_PRICE[java.util.Arrays.asList(TIERS).indexOf(a[1])];
                case "w" -> WHEEL_PRICE[java.util.Arrays.asList(WHEELS).indexOf(a[1])];
                case "c" -> 400;
                case "s" -> STAGE_PRICE[Integer.parseInt(a[1]) - 1];
                default -> -1;
            };
        } catch (Exception e) { return -1; }
    }

    static void buy(ServerPlayer p, BlockPos at, String id) {
        Entity v = find(p, at);
        long pr = price(id);
        if (v == null || pr < 0) return;
        String[] a = id.split(":");
        UUID u = p.getUUID();
        ItemStack st = null;
        if (a[0].equals("e")) st = new ItemStack(Util.item("vehicle:" + a[1] + "_" + engType(v) + "_engine"));
        if (a[0].equals("w")) st = new ItemStack(Util.item("vehicle:" + a[1] + "_wheel"));
        if (st != null && (st.isEmpty() || st.getItem() == net.minecraft.world.item.Items.AIR)) { Util.msg(p, "§cPiesă indisponibilă pentru acest vehicul."); return; }
        if (a[0].equals("s") && Integer.parseInt(a[1]) <= v.getPersistentData().getInt("moon_stage")) { Util.msg(p, "§cAi deja acest stage sau unul mai bun."); return; }
        if (!Bank.take(u, pr, "MoonTuning " + id)) { Util.msg(p, "§cFonduri insuficiente."); return; }
        switch (a[0]) {
            case "e" -> Veh.setEngine(v, st);
            case "w" -> Veh.setWheel(v, st);
            case "c" -> Veh.setColor(v, Integer.parseInt(a[1], 16));
            case "s" -> { v.getPersistentData().putInt("moon_stage", Integer.parseInt(a[1])); Veh.applySpeed(v); }
            default -> { }
        }
        // comision 10% pentru un mecanic aflat in apropiere
        for (ServerPlayer m : p.serverLevel().players())
            if (!m.getUUID().equals(u) && Jobs.is(m.getUUID(), "mechanic") && m.distanceToSqr(p) < 400) { Bank.add(m.getUUID(), pr / 10, "Comision tuning"); break; }
        Util.msg(p, "§aTuning aplicat: " + id);
    }
}
