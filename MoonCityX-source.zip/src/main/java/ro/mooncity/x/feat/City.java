package ro.mooncity.x.feat;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import ro.mooncity.x.*;

import java.util.*;

/** Primarie: buget, alegeri, teritorii, medic, statii de autobuz, proprietati. */
public class City {
    static final String[] ZONES = {"Centru", "Port", "Zona Industrială", "Cartierul Nord", "Piața Veche", "Aeroport"};

    static CompoundTag city() { return Db.sec("city"); }

    public static long budget() { return city().getLong("budget"); }

    public static void budget(long amt, String why) {
        if (amt <= 0) return;
        city().putLong("budget", budget() + amt);
        Db.dirty();
    }

    public static boolean budgetPay(long amt, String why) {
        if (budget() < amt) return false;
        city().putLong("budget", budget() - amt);
        Db.dirty();
        return true;
    }

    public static UUID mayor() {
        String m = city().getString("mayor");
        return m.isEmpty() ? null : UUID.fromString(m);
    }

    public static void cityMenu(ServerPlayer p) {
        UUID m = mayor();
        Ui u = Ui.of("§9Primăria MoonCity")
            .line("§7Buget oraș: §a" + Util.fmt(budget()))
            .line("§7Primar: §f" + (m == null ? "— vacant —" : Db.name(m)))
            .line("§7Cota impozit venit: §f" + Math.round(Cfg.I.incomeTax * 100) + "%  §7TVA: §f" + Math.round(Cfg.I.vat * 100) + "%")
            .sep()
            .btn("Buletin (" + Util.fmt(Db.p(p.getUUID()).contains("idDate") ? Cfg.I.idCardPrice / 2 : Cfg.I.idCardPrice) + ")", "docs:buyid")
            .btn("Duplicat permis", "docs:dupl")
            .btn("Alegeri", "pol:menu")
            .btn("Teritorii", "terr:menu")
            .btn("Medic", "med:menu");
        if (m != null && m.equals(p.getUUID())) u.sep().line("§6Meniu primar:").in("rate", "Impozit venit % (0-30)", "10").btn("Setează impozit", "city:tax");
        u.send(p);
    }

    // ---------------- medic ----------------
    public static void medMenu(ServerPlayer p) {
        Ui.of("§fMedic")
            .line("§7Cumpără echipament medical sau fă o consultație.")
            .btn("Trusă medicală (" + Util.fmt(Cfg.I.medkitPrice) + ")", "med:buy", "i", "kit")
            .btn("Bandaj (" + Util.fmt(Cfg.I.bandagePrice) + ")", "med:buy", "i", "band")
            .btn("Consultație - vindecare completă (" + Util.fmt(Cfg.I.medConsult) + ")", "med:consult")
            .send(p);
    }

    // ---------------- teritorii ----------------
    public static void terrMenu(ServerPlayer p) {
        CompoundTag t = Db.sub(city(), "terr");
        Ui u = Ui.of("§cTeritorii").line("§7Preț: §f" + Util.fmt(Cfg.I.territoryPrice) + " §7• venit: §a" + Util.fmt(Cfg.I.territoryIncomePerHour) + "/oră");
        for (int i = 0; i < ZONES.length; i++) {
            String o = t.getString("z" + i);
            if (o.isEmpty()) u.btn(ZONES[i] + " - liber, cumpără", "terr:buy", "z", i);
            else u.line("§f" + ZONES[i] + " §7→ §e" + Db.name(UUID.fromString(o)));
        }
        u.send(p);
    }

    /** Apelat la fiecare ora de joc-timp-real. */
    public static void hourly(MinecraftServer srv) {
        CompoundTag t = Db.sub(city(), "terr");
        for (String k : t.getAllKeys()) {
            String o = t.getString(k);
            if (o.isEmpty()) continue;
            UUID u = UUID.fromString(o);
            if (budgetPay(Cfg.I.territoryIncomePerHour, "Venit teritoriu")) Bank.add(u, Cfg.I.territoryIncomePerHour, "Venit teritoriu");
        }
    }

    // ---------------- alegeri ----------------
    static void polMenu(ServerPlayer p) {
        CompoundTag pol = Db.sub(city(), "pol");
        CompoundTag cands = Db.sub(pol, "cands");
        Ui u = Ui.of("§9Alegeri primar").line("§7Înscriere candidat: §f" + Util.fmt(Cfg.I.candidateFee));
        for (String k : cands.getAllKeys())
            u.btn(Db.name(UUID.fromString(k)) + " - " + cands.getCompound(k).getInt("votes") + " voturi", "pol:vote", "c", k);
        u.btn("Mă înscriu candidat", "pol:run");
        if (Util.op(p)) u.btn("§cÎncheie alegeri (admin)", "pol:end");
        u.send(p);
    }

    // ---------------- proprietati ----------------
    static void propMenu(ServerPlayer p, long pos) {
        CompoundTag props = Db.sub(city(), "props");
        String k = Long.toString(pos);
        CompoundTag pr = Db.sub(props, k);
        if (!pr.contains("price")) pr.putLong("price", 20000);
        String o = pr.getString("owner");
        Ui u = Ui.of("§aProprietate");
        CompoundTag keep = new CompoundTag();
        keep.putLong("pos", pos);
        if (o.isEmpty()) u.line("§7Preț: §f" + Util.fmt(pr.getLong("price"))).btn("Cumpără", "prop:buy", keep);
        else {
            u.line("§7Proprietar: §f" + Db.name(UUID.fromString(o)));
            if (o.equals(p.getUUID().toString())) u.btn("Vinde înapoi statului (70%)", "prop:sell", keep);
        }
        u.send(p);
    }

    public static void act(String m, ServerPlayer p, String s, CompoundTag d) {
        UUID u = p.getUUID();
        switch (m) {
            case "city" -> {
                if (s.equals("tax") && u.equals(mayor())) {
                    long r = Math.max(0, Math.min(30, Util.num(d, "rate")));
                    Cfg.I.incomeTax = r / 100.0;
                    Util.msg(p, "§aImpozit setat la " + r + "%");
                }
                cityMenu(p);
            }
            case "med" -> {
                switch (s) {
                    case "buy" -> {
                        boolean kit = Util.str(d, "i").equals("kit");
                        long pr = kit ? Cfg.I.medkitPrice : Cfg.I.bandagePrice;
                        if (Bank.take(u, pr, kit ? "Trusă medicală" : "Bandaj")) {
                            Util.give(p, new ItemStack(kit ? Reg.MEDKIT.get() : Reg.BANDAGE.get()));
                            City.budget(pr / 4, "Vânzare medicală");
                        } else Util.msg(p, "§cFonduri insuficiente.");
                    }
                    case "consult" -> {
                        if (Bank.take(u, Cfg.I.medConsult, "Consultație medic")) { p.setHealth(p.getMaxHealth()); p.getFoodData().setFoodLevel(20); Util.msg(p, "§aEști vindecat."); }
                        else Util.msg(p, "§cFonduri insuficiente.");
                    }
                    default -> { }
                }
                medMenu(p);
            }
            case "terr" -> {
                if (s.equals("buy")) {
                    CompoundTag t = Db.sub(city(), "terr");
                    String key = "z" + (int) Util.num(d, "z");
                    if (!t.getString(key).isEmpty()) Util.msg(p, "§cDeja deținut.");
                    else if (!Bank.take(u, Cfg.I.territoryPrice, "Cumpărare teritoriu")) Util.msg(p, "§cFonduri insuficiente.");
                    else { t.putString(key, u.toString()); budget(Cfg.I.territoryPrice, "Vânzare teritoriu"); Db.dirty(); }
                }
                terrMenu(p);
            }
            case "pol" -> {
                CompoundTag pol = Db.sub(city(), "pol");
                CompoundTag cands = Db.sub(pol, "cands");
                CompoundTag voted = Db.sub(pol, "voted");
                switch (s) {
                    case "run" -> {
                        if (cands.contains(u.toString())) Util.msg(p, "§cEști deja candidat.");
                        else if (Bank.take(u, Cfg.I.candidateFee, "Taxă candidatură")) { cands.put(u.toString(), new CompoundTag()); budget(Cfg.I.candidateFee, "Taxă candidatură"); }
                        else Util.msg(p, "§cFonduri insuficiente.");
                    }
                    case "vote" -> {
                        String c = Util.str(d, "c");
                        if (voted.contains(u.toString())) Util.msg(p, "§cAi votat deja.");
                        else if (cands.contains(c)) { CompoundTag cc = cands.getCompound(c); cc.putInt("votes", cc.getInt("votes") + 1); voted.putBoolean(u.toString(), true); Util.msg(p, "§aVot înregistrat."); }
                    }
                    case "end" -> {
                        if (Util.op(p)) {
                            String best = null; int bv = -1;
                            for (String k : cands.getAllKeys()) { int v = cands.getCompound(k).getInt("votes"); if (v > bv) { bv = v; best = k; } }
                            if (best != null) { city().putString("mayor", best); for (ServerPlayer o : p.server.getPlayerList().getPlayers()) Util.msg(o, "§9[Alegeri] Noul primar: §f" + Db.name(UUID.fromString(best))); }
                            pol.remove("cands"); pol.remove("voted");
                        }
                    }
                    default -> { }
                }
                Db.dirty();
                polMenu(p);
            }
            case "bus" -> {
                if (Bank.take(u, Cfg.I.busTicket, "Bilet autobuz")) { budget(Cfg.I.busTicket, "Bilet autobuz"); Util.bar(p, "§aBilet cumpărat (" + Util.fmt(Cfg.I.busTicket) + ")."); }
                else Util.bar(p, "§cFonduri insuficiente.");
            }
            case "prop" -> {
                long pos = d.getLong("pos");
                CompoundTag pr = Db.sub(Db.sub(city(), "props"), Long.toString(pos));
                if (s.equals("buy") && pr.getString("owner").isEmpty()) {
                    long price = pr.contains("price") ? pr.getLong("price") : 20000;
                    if (Bank.take(u, price, "Cumpărare proprietate")) { pr.putString("owner", u.toString()); budget(price, "Vânzare proprietate"); }
                    else Util.msg(p, "§cFonduri insuficiente.");
                } else if (s.equals("sell") && pr.getString("owner").equals(u.toString())) {
                    long price = pr.contains("price") ? pr.getLong("price") : 20000;
                    if (budgetPay(price * 7 / 10, "Răscumpărare proprietate")) { Bank.add(u, price * 7 / 10, "Vânzare proprietate"); pr.putString("owner", ""); }
                }
                Db.dirty();
                propMenu(p, pos);
            }
            default -> cityMenu(p);
        }
    }
}
