package ro.mooncity.x.feat;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import ro.mooncity.x.*;

import java.util.UUID;

/** Scoala de soferi: examen teoretic (NPC) sau instructor jucator (job "instructor"). */
public class School {
    static final String[][] Q = {
        {"Culoarea semaforului care cere oprire?", "1) Verde", "2) Roșu", "3) Albastru", "2"},
        {"Viteza maximă în localitate (RO)?", "1) 50 km/h", "2) 90 km/h", "3) 130 km/h", "1"},
        {"Centura de siguranță se poartă:", "1) Doar pe autostradă", "2) Niciodată", "3) Întotdeauna", "3"}
    };

    public static void menu(ServerPlayer p) {
        UUID u = p.getUUID();
        Ui ui = Ui.of("§eȘcoala de șoferi");
        if (Docs.hasLicense(u)) { ui.line("§aAi deja permis categoria B.").btn("Duplicat permis", "docs:dupl").send(p); return; }
        boolean paid = Db.p(u).getBoolean("examPaid");
        if (!paid) {
            ui.line("§7Taxă examen: §f" + Util.fmt(Cfg.I.examPrice))
              .line("§7Poți da examenul teoretic aici sau cere unui instructor (jucător) să te valideze.")
              .btn("Plătește și începe", "school:start");
        } else {
            for (int i = 0; i < Q.length; i++) ui.line("§f" + (i + 1) + ". " + Q[i][0] + " §7" + Q[i][1] + "  " + Q[i][2] + "  " + Q[i][3]);
            ui.in("a1", "Răspuns 1 (1-3)", "").in("a2", "Răspuns 2 (1-3)", "").in("a3", "Răspuns 3 (1-3)", "").btn("Trimite examen", "school:submit");
        }
        if (Jobs.is(u, "instructor")) ui.sep().line("§6Instructor:").in("who", "ID/nume elev", "").btn("Validează elev (plătit)", "school:approve");
        ui.send(p);
    }

    public static void act(ServerPlayer p, String s, CompoundTag d) {
        UUID u = p.getUUID();
        CompoundTag r = Db.p(u);
        switch (s) {
            case "start" -> {
                if (!r.getBoolean("examPaid") && !Docs.hasLicense(u)) {
                    if (Bank.take(u, Cfg.I.examPrice, "Taxă examen auto")) { r.putBoolean("examPaid", true); City.budget(Cfg.I.examPrice / 2, "Taxă examen"); }
                    else Util.msg(p, "§cFonduri insuficiente.");
                }
            }
            case "submit" -> {
                if (!r.getBoolean("examPaid")) break;
                int ok = 0;
                for (int i = 0; i < Q.length; i++) if (Util.str(d, "a" + (i + 1)).equals(Q[i][4])) ok++;
                if (ok >= 2) { r.putBoolean("examPaid", false); Docs.grantLicense(p); }
                else { Util.msg(p, "§cPicat (" + ok + "/3). Mai încearcă — examenul rămâne plătit."); }
            }
            case "approve" -> {
                if (!Jobs.is(u, "instructor")) { Util.msg(p, "§cNu ești instructor."); break; }
                UUID t = Db.find(Util.str(d, "who"));
                ServerPlayer tp = t == null ? null : Util.online(t);
                if (tp == null || !Db.p(t).getBoolean("examPaid")) { Util.msg(p, "§cElevul nu e online sau nu a plătit examenul."); break; }
                Db.p(t).putBoolean("examPaid", false);
                Docs.grantLicense(tp);
                Jobs.reward(p, "instructor", 150, "Elev validat");
            }
            default -> { }
        }
        menu(p);
    }
}
