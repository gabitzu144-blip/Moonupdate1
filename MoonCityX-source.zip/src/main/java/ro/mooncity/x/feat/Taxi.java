package ro.mooncity.x.feat;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import ro.mooncity.x.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

/** MoonTaxi: comenzi, tarife, evaluari, curse inregistrate (vizibile in MDT). */
public class Taxi {
    static CompoundTag orders() { return Db.sub(Db.sec("taxi"), "orders"); }

    static ListTag rides() { return Db.list(Db.sec("taxi"), "rides"); }

    static long fare(double km) { return Math.round(Cfg.I.taxiStart + km * Cfg.I.taxiPerKm); }

    public static void menu(ServerPlayer p) {
        UUID u = p.getUUID();
        CompoundTag me = Db.p(u);
        Ui ui = Ui.of("§eMoonTaxi")
            .line("§7Tarif: §f" + Cfg.I.taxiStart + " RON pornire + " + Cfg.I.taxiPerKm + " RON/km");
        if (me.contains("rate")) {
            ui.line("§eEvaluează ultima cursă:");
            for (int i = 1; i <= 5; i++) ui.btn(i + " ★", "taxi:rate", "n", i);
        }
        CompoundTag o = orders();
        String k = u.toString();
        if (o.contains(k, Tag.TAG_COMPOUND)) {
            CompoundTag c = o.getCompound(k);
            int st = c.getInt("state");
            if (st == 0) ui.line("§7Comanda ta așteaptă un șofer…");
            else if (st == 1) ui.line("§aȘofer: §f" + Db.name(UUID.fromString(c.getString("driver"))) + " §7vine spre tine.");
            else ui.line("§aEști în cursă: §f" + String.format("%.2f", c.getDouble("km")) + " km • " + Util.fmt(fare(c.getDouble("km"))));
            if (st < 2) ui.btn("Anulează comanda", "taxi:cancel");
        } else {
            ui.in("note", "Mesaj pentru șofer (opțional)", "").btn("Comandă un taxi aici", "taxi:order");
        }
        if (Jobs.is(u, "taxi")) {
            boolean duty = me.getBoolean("duty");
            ui.sep().line("§6— Șofer taxi — §7Rating: " + rating(u) + " (" + me.getInt("tx_cnt") + " curse)");
            ui.btn("Tură: " + (duty ? "§aPE TURĂ (apasă pt. a ieși)" : "§cOFF (apasă pt. a intra)"), "taxi:duty");
            if (duty) {
                for (String ck : o.getAllKeys()) {
                    CompoundTag c = o.getCompound(ck);
                    if (c.getInt("state") == 0) {
                        double dd = Math.sqrt(p.distanceToSqr(c.getDouble("x"), c.getDouble("y"), c.getDouble("z")));
                        ui.btn("Preia: " + c.getString("name") + " (" + Math.round(dd) + " m) " + c.getString("note"), "taxi:accept", "c", ck);
                    } else if (c.getString("driver").equals(k)) { /* afisat mai jos */ }
                    if (c.getString("driver").equals(k)) {
                        ui.line("§aCursa ta: §f" + c.getString("name") + " • " + String.format("%.2f", c.getDouble("km")) + " km • " + Util.fmt(fare(c.getDouble("km"))));
                        if (c.getInt("state") == 1) ui.btn("Pornește cursa (clientul lângă tine)", "taxi:start", "c", ck);
                        ui.btn("Termină cursa și încasează", "taxi:end", "c", ck);
                    }
                }
            }
        }
        ui.send(p);
    }

    static String rating(UUID u) {
        CompoundTag r = Db.p(u);
        int c = r.getInt("tx_cnt");
        return c == 0 ? "—" : String.format("%.1f ★", r.getInt("tx_sum") / (double) c);
    }

    public static void act(ServerPlayer p, String s, CompoundTag d) {
        UUID u = p.getUUID();
        CompoundTag o = orders();
        String k = u.toString();
        switch (s) {
            case "order" -> {
                CompoundTag c = new CompoundTag();
                c.putString("name", p.getName().getString());
                c.putDouble("x", p.getX());
                c.putDouble("y", p.getY());
                c.putDouble("z", p.getZ());
                c.putString("note", Util.str(d, "note"));
                c.putInt("state", 0);
                o.put(k, c);
                int n = 0;
                for (ServerPlayer o2 : p.server.getPlayerList().getPlayers())
                    if (Jobs.is(o2.getUUID(), "taxi") && Db.p(o2.getUUID()).getBoolean("duty")) { Util.msg(o2, "§e[MoonTaxi] Comandă nouă de la " + p.getName().getString()); n++; }
                Util.msg(p, n == 0 ? "§eComandă trimisă, dar nu sunt șoferi pe tură acum." : "§aComandă trimisă către " + n + " șofer(i).");
            }
            case "cancel" -> {
                CompoundTag c = o.getCompound(k);
                if (!c.isEmpty() && c.getInt("state") < 2) {
                    ServerPlayer dr = c.getString("driver").isEmpty() ? null : Util.online(UUID.fromString(c.getString("driver")));
                    if (dr != null) Util.msg(dr, "§c[MoonTaxi] Clientul a anulat comanda.");
                    o.remove(k);
                }
            }
            case "duty" -> Db.p(u).putBoolean("duty", !Db.p(u).getBoolean("duty"));
            case "accept" -> {
                CompoundTag c = o.getCompound(Util.str(d, "c"));
                if (!c.isEmpty() && c.getInt("state") == 0 && Jobs.is(u, "taxi")) {
                    c.putInt("state", 1);
                    c.putString("driver", k);
                    c.putDouble("km", 0);
                    ServerPlayer cu = Util.online(UUID.fromString(Util.str(d, "c")));
                    if (cu != null) Util.msg(cu, "§a[MoonTaxi] " + p.getName().getString() + " a preluat comanda ta.");
                    Util.msg(p, "§aAi preluat comanda. Mergi la " + (int) c.getDouble("x") + ", " + (int) c.getDouble("z"));
                }
            }
            case "start" -> {
                CompoundTag c = o.getCompound(Util.str(d, "c"));
                ServerPlayer cu = Util.online(UUID.fromString(Util.str(d, "c")));
                if (c.getString("driver").equals(k) && cu != null && cu.distanceToSqr(p) < 100) {
                    c.putInt("state", 2);
                    c.putDouble("lx", p.getX());
                    c.putDouble("lz", p.getZ());
                    c.putString("t0", LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd.MM HH:mm")));
                    Util.msg(cu, "§e[MoonTaxi] Cursa a început.");
                } else Util.msg(p, "§cClientul trebuie să fie lângă tine (10 blocuri).");
            }
            case "end" -> end(p, Util.str(d, "c"));
            case "rate" -> {
                CompoundTag me = Db.p(u);
                if (me.contains("rate")) {
                    int n = (int) Math.max(1, Math.min(5, Util.num(d, "n")));
                    UUID dr = UUID.fromString(me.getString("rate"));
                    CompoundTag dd = Db.p(dr);
                    dd.putInt("tx_sum", dd.getInt("tx_sum") + n);
                    dd.putInt("tx_cnt", dd.getInt("tx_cnt") + 1);
                    Social.addRep(dr, n - 3);
                    ListTag rl = rides();
                    if (rl.size() > 0) rl.getCompound(rl.size() - 1).putInt("rating", n);
                    me.remove("rate");
                    Util.msg(p, "§aMulțumim pentru evaluare!");
                }
            }
            default -> { }
        }
        Db.dirty();
        menu(p);
    }

    static void end(ServerPlayer p, String ck) {
        CompoundTag o = orders();
        CompoundTag c = o.getCompound(ck);
        if (c.isEmpty() || !c.getString("driver").equals(p.getUUID().toString())) return;
        UUID cu = UUID.fromString(ck);
        double km = c.getDouble("km");
        long f = c.getInt("state") == 2 ? fare(km) : 0;
        if (f > 0) {
            if (Bank.take(cu, f, "MoonTaxi cursă " + String.format("%.1f", km) + " km")) {
                long cut = Math.round(f * Cfg.I.taxiCompanyCut);
                City.budget(cut, "Taxă MoonTaxi");
                Bank.add(p.getUUID(), f - cut, "Cursă taxi " + c.getString("name"));
                Util.msg(p, "§aAi încasat " + Util.fmt(f - cut) + " (comision companie " + Util.fmt(cut) + ")");
                ServerPlayer cp = Util.online(cu);
                if (cp != null) Util.msg(cp, "§e[MoonTaxi] Total: " + Util.fmt(f) + " (" + String.format("%.2f", km) + " km). Evaluează cursa din telefon.");
                Db.p(cu).putString("rate", p.getUUID().toString());
            } else {
                Util.msg(p, "§cClientul nu are fonduri; cursa se înregistrează ca datorie în MDT.");
                Mdt.fine(cu, f, "Neplată cursă taxi", "MoonTaxi");
            }
            CompoundTag rl = new CompoundTag();
            rl.putString("driver", p.getUUID().toString());
            rl.putString("cust", ck);
            rl.putDouble("km", km);
            rl.putLong("fare", f);
            rl.putString("at", c.getString("t0"));
            rl.putInt("rating", 0);
            ListTag rides = rides();
            rides.add(rl);
            while (rides.size() > 200) rides.remove(0);
        }
        o.remove(ck);
    }

    /** La fiecare 20 tick-uri: contorizeaza kilometrii cursei. */
    public static void tick(MinecraftServer srv) {
        CompoundTag o = orders();
        for (String ck : o.getAllKeys()) {
            CompoundTag c = o.getCompound(ck);
            if (c.getInt("state") != 2) continue;
            ServerPlayer dr = Util.online(UUID.fromString(c.getString("driver")));
            if (dr == null) continue;
            double dx = dr.getX() - c.getDouble("lx"), dz = dr.getZ() - c.getDouble("lz");
            double dist = Math.sqrt(dx * dx + dz * dz);
            if (dist < 120) c.putDouble("km", c.getDouble("km") + dist / 1000.0);
            c.putDouble("lx", dr.getX());
            c.putDouble("lz", dr.getZ());
            Util.bar(dr, "§e🚖 " + String.format("%.2f", c.getDouble("km")) + " km • " + Util.fmt(fare(c.getDouble("km"))));
        }
    }

    public static void ridesMenu(ServerPlayer p) {
        Ui ui = Ui.of("§9Curse taxi înregistrate");
        ListTag r = rides();
        for (int i = r.size() - 1; i >= 0 && i >= r.size() - 20; i--) {
            CompoundTag c = r.getCompound(i);
            ui.line("§f" + c.getString("at") + " §7" + Db.name(UUID.fromString(c.getString("driver"))) + " → " + Db.name(UUID.fromString(c.getString("cust")))
                + " • " + String.format("%.1f", c.getDouble("km")) + " km • " + Util.fmt(c.getLong("fare")) + " • " + (c.getInt("rating") == 0 ? "—" : c.getInt("rating") + "★"));
        }
        ui.btn("« MDT", "mdt:main").send(p);
    }
}
