package ro.mooncity.x.feat;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import ro.mooncity.x.*;

import java.time.LocalDate;
import java.util.*;

/** Depozit: incarci cutii (10 kg) in portbagajul vehiculului de langa tine sau in inventar si le duci la destinatie. */
public class Cargo {
    static final String BOX = "mooncityx:moonbox";

    record Ship(String name, int boxes, int x, int z, long reward) { }

    static List<Ship> ships(ServerPlayer p) {
        Random r = new Random(Db.id(p.getUUID()) * 17L + LocalDate.now().toEpochDay() * 13);
        String[] names = {"Colete magazin", "Piese auto", "Alimente", "Materiale construcții", "Electronice", "Marfă la pachet"};
        int[] sizes = {4, 8, 12, 20, 30};
        BlockPos sp = p.serverLevel().getSharedSpawnPos();
        List<Ship> l = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            int b = sizes[i];
            double a = r.nextDouble() * Math.PI * 2, dist = 150 + r.nextInt(300);
            int x = sp.getX() + (int) (Math.cos(a) * dist), z = sp.getZ() + (int) (Math.sin(a) * dist);
            long rew = Math.round(dist * 4 + b * 60L);
            l.add(new Ship(names[r.nextInt(names.length)], b, x, z, rew));
        }
        return l;
    }

    public static void menu(ServerPlayer p) {
        Ui u = Ui.of("§6Depozit – transport marfă");
        Entity v = Util.nearestVehicle(p, 12);
        double room = Cfg.I.carryKg - Weights.total(p);
        u.line("§7O cutie = §f" + (int) Cfg.I.boxKg + " kg§7. Încărcarea se face în portbagajul vehiculului de lângă tine (max 12 blocuri) sau în inventar.");
        u.line("§7Vehicul: " + (v == null ? "§cniciunul în apropiere" : "§f" + Trunk.typeOf(v) + " §7(liber " + Weights.fmt(Trunk.capacity(v) - Trunk.used(v)) + " kg)"));
        u.line("§7Inventar: liber §f" + Weights.fmt(Math.max(0, room)) + " kg");
        u.sep().line("§eExpediții de azi:");
        List<Ship> l = ships(p);
        for (int i = 0; i < l.size(); i++) {
            Ship s = l.get(i);
            u.btn(s.name() + " – " + s.boxes() + " cutii (" + (int) (s.boxes() * Cfg.I.boxKg) + " kg) → " + s.x() + ", " + s.z() + " §a" + Util.fmt(s.reward()), "cargo:acc", "i", i);
        }
        u.sep().btn("§bPortbagaj vehicul", "trunk:open");
        u.send(p);
    }

    public static void act(ServerPlayer p, String s, CompoundTag d) {
        if (!s.equals("acc")) { menu(p); return; }
        CompoundTag r = Db.p(p.getUUID());
        ListTag act = Db.list(r, "ctr");
        List<Ship> l = ships(p);
        int i = d.getInt("i");
        if (act.size() >= 3) { Util.msg(p, "§cAi deja 3 contracte active."); menu(p); return; }
        for (int k = 0; k < act.size(); k++) if (act.getCompound(k).getInt("boxes") > 0) { Util.msg(p, "§cAi deja o expediție în curs."); menu(p); return; }
        if (i < 0 || i >= l.size()) { menu(p); return; }
        Ship sh = l.get(i);
        Entity v = Util.nearestVehicle(p, 12);
        ItemStack box = Util.item(BOX) == null ? ItemStack.EMPTY : new ItemStack(Util.item(BOX));
        int left = sh.boxes();
        int inTrunk = 0;
        if (v != null && !box.isEmpty()) {
            UUID o = Util.owner(v);
            if (o == null || o.equals(p.getUUID()) || Util.op(p)) {
                inTrunk = Trunk.add(v, box.copyWithCount(left));
                left -= inTrunk;
            }
        }
        double each = Cfg.I.boxKg;
        int inInv = (int) Math.max(0, Math.min(left, Math.floor((Cfg.I.carryKg - Weights.total(p)) / each)));
        if (left - inInv > 0) {
            if (inTrunk > 0 && v != null) Trunk.remove(v, BOX, inTrunk);
            Util.msg(p, "§cNu ai loc pentru " + sh.boxes() + " cutii (" + (int) (sh.boxes() * each) + " kg). Apropie un vehicul mai mare sau eliberează inventarul.");
            menu(p);
            return;
        }
        if (inInv > 0) Util.give(p, box.copyWithCount(inInv));
        CompoundTag c = new CompoundTag();
        c.putString("title", sh.name() + " (" + sh.boxes() + " cutii) → " + sh.x() + ", " + sh.z());
        c.putInt("kind", 1);
        c.putString("item", "");
        c.putInt("count", 0);
        c.putInt("boxes", sh.boxes());
        c.putInt("x", sh.x());
        c.putInt("z", sh.z());
        c.putLong("reward", Jobs.is(p.getUUID(), "delivery") ? Math.round(sh.reward() * 1.25) : sh.reward());
        c.putBoolean("ill", false);
        act.add(c);
        Db.dirty();
        Util.msg(p, "§aAi încărcat " + inTrunk + " cutii în portbagaj și " + inInv + " în inventar. Urmează raza de pe ecran până la destinație!");
        menu(p);
    }

    /** Cutii disponibile jucatorului: inventar + portbagajul vehiculului din apropiere. */
    public static int have(ServerPlayer p) {
        int n = Util.count(p, BOX);
        Entity v = Util.nearestVehicle(p, 25);
        if (v != null) n += Trunk.count(v, BOX);
        return n;
    }

    public static void take(ServerPlayer p, int n) {
        int got = Util.remove(p, BOX, n);
        Entity v = Util.nearestVehicle(p, 25);
        if (got < n && v != null) Trunk.remove(v, BOX, n - got);
    }
}
