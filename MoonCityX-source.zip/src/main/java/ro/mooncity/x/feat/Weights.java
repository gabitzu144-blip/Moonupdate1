package ro.mooncity.x.feat;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.*;
import net.minecraftforge.registries.ForgeRegistries;
import ro.mooncity.x.Cfg;

/** Greutate in kg (stil FiveM): limita de transport, incetinire cand esti supraincarcat. */
public class Weights {
    public static double of(ItemStack s) {
        if (s.isEmpty()) return 0;
        var k = ForgeRegistries.ITEMS.getKey(s.getItem());
        String id = k == null ? "" : k.toString();
        Double o = Cfg.I.weights.get(id);
        double w;
        if (o != null) w = o;
        else {
            String p = k == null ? "" : k.getPath();
            Item it = s.getItem();
            if (id.equals("mooncityx:moonbox")) w = 10;
            else if (p.startsWith("bani_")) w = 0.002;
            else if (id.startsWith("mooncityx:")) w = 0.1;
            else if (p.contains("nugget")) w = 0.05;
            else if (p.contains("ingot")) w = 0.5;
            else if (p.equals("diamond") || p.equals("emerald") || p.equals("coal") || p.contains("pearl")) w = 0.3;
            else if (p.contains("log") || p.contains("wood")) w = 2.5;
            else if (p.contains("ore") || p.contains("cobble") || p.contains("stone")) w = 1.5;
            else if (it instanceof ArmorItem) w = 3;
            else if (it instanceof DiggerItem || it instanceof SwordItem || it instanceof BowItem || it instanceof CrossbowItem) w = 2;
            else if (it instanceof BlockItem) w = 1;
            else if (s.isEdible()) w = 0.3;
            else w = 0.2;
        }
        return w * s.getCount();
    }

    public static double total(ServerPlayer p) {
        double t = 0;
        var inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) t += of(inv.getItem(i));
        return t;
    }

    public static String fmt(double kg) { return String.format(java.util.Locale.ROOT, "%.1f", kg); }

    /** La 1 s: supraincarcat -> slowness progresiv. */
    public static void tick(ServerPlayer p) {
        if (p.isCreative() || p.isSpectator()) return;
        double ratio = total(p) / Math.max(1.0, Cfg.I.carryKg);
        if (ratio <= 1.0) return;
        int amp = ratio > 1.6 ? 3 : ratio > 1.25 ? 1 : 0;
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, amp, false, false, true));
        if (ratio > 1.0) ro.mooncity.x.Util.bar(p, "§cSupraîncărcat! " + fmt(total(p)) + "/" + (int) Cfg.I.carryKg + " kg");
    }
}
