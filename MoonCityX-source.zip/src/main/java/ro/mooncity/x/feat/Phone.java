package ro.mooncity.x.feat;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import ro.mooncity.x.*;

import java.util.UUID;

/** Aplicatiile telefonului. Clientul deschide ecranul telefonului; fiecare aplicatie apeleaza "phone:app". */
public class Phone {
    public static void act(ServerPlayer p, String s, CompoundTag d) {
        UUID u = p.getUUID();
        switch (s) {
            case "app" -> {
                switch (Util.str(d, "a")) {
                    case "bank" -> Bank.main(p);
                    case "taxi" -> Taxi.menu(p);
                    case "contacts" -> contacts(p);
                    case "jobs" -> Jobs.menu(p);
                    case "news" -> Social.newsMenu(p);
                    case "gov" -> City.cityMenu(p);
                    case "terr" -> City.terrMenu(p);
                    case "rep" -> Social.repMenu(p);
                    case "med" -> City.medMenu(p);
                    case "ctr" -> Contracts.menu(p, false);
                    case "settings" -> settings(p);
                    case "map" -> Ui.of("§bHartă").line("§7Poziția ta: §f" + Util.pos(p.blockPosition()))
                        .line("§7Dimensiune: §f" + p.level().dimension().location()).send(p);
                    default -> { }
                }
            }
            case "open" -> Net.to(p, "phone", new CompoundTag());
            case "msg" -> {
                UUID t = Db.find(Util.str(d, "to"));
                String m = Util.str(d, "m");
                ServerPlayer tp = t == null ? null : Util.online(t);
                if (tp == null || m.isEmpty()) Util.msg(p, "§cDestinatar offline sau mesaj gol.");
                else {
                    Util.msg(tp, "§d[SMS de la " + p.getName().getString() + " (ID " + Db.id(u) + ")] §f" + m);
                    Util.msg(p, "§d[SMS către " + tp.getName().getString() + "] §f" + m);
                }
                contacts(p);
            }
            case "set" -> {
                CompoundTag r = Db.p(u);
                if (Util.str(d, "k").equals("hud")) r.putInt("hud", 1 - r.getInt("hud"));
                if (Util.str(d, "k").equals("pay")) r.putInt("pay", 1 - r.getInt("pay"));
                Bank.sync(u);
                settings(p);
            }
            default -> { }
        }
    }

    static void contacts(ServerPlayer p) {
        Ui u = Ui.of("§aContacte & SMS").line("§7Jucători online:");
        for (ServerPlayer o : p.server.getPlayerList().getPlayers())
            u.line("§f" + o.getName().getString() + " §7(ID " + Db.id(o.getUUID()) + ")");
        u.in("to", "Către (ID/nume)", "").in("m", "Mesaj", "").btn("Trimite SMS", "phone:msg").send(p);
    }

    static void settings(ServerPlayer p) {
        CompoundTag r = Db.p(p.getUUID());
        Ui.of("§7Setări")
            .line("§7ID-ul tău: §f" + r.getInt("id") + "  §7IBAN: §f" + Bank.iban(p.getUUID()))
            
            .btn("Plată: " + (r.getInt("pay") == 0 ? "numerar apoi card" : "doar card"), "phone:set", "k", "pay")
            .send(p);
    }
}
