package ro.mooncity.x.feat;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import ro.mooncity.x.*;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/** Joburi: miner, taietor, fermier, pescar (platite pe actiune), taxi/autobuz/medic/politist/mecanic/instructor (alte sisteme). */
public class Jobs {
    public static final Map<String, String[]> ALL = new LinkedHashMap<>();
    static {
        ALL.put("miner", new String[]{"Miner", "Minezi minereuri și piatră (2-8 RON/bloc)"});
        ALL.put("lumberjack", new String[]{"Tăietor de lemne", "Tai copaci (3 RON/buștean)"});
        ALL.put("farmer", new String[]{"Fermier", "Recoltezi culturi coapte (3 RON/bucată)"});
        ALL.put("fisher", new String[]{"Pescar", "Pescuiești (10 RON/pește)"});
        ALL.put("delivery", new String[]{"Curier", "Bonus +25% la contractele de livrare"});
        ALL.put("taxi", new String[]{"Șofer taxi", "Preia comenzi MoonTaxi"});
        ALL.put("bus", new String[]{"Șofer autobuz", "Primești bani pentru pasagerii cu bilet + salariu"});
        ALL.put("medic", new String[]{"Medic", "Tratezi pacienți, consultații, trusă medicală + salariu"});
        ALL.put("police", new String[]{"Polițist", "Folosești MDT, amenzi, căutări + salariu"});
        ALL.put("mechanic", new String[]{"Mecanic", "Comision 10% din tuning + salariu"});
        ALL.put("instructor", new String[]{"Instructor auto", "Acorzi permise la elevi + salariu"});
    }

    public static String name(String id) { return ALL.containsKey(id) ? ALL.get(id)[0] : "Șomer"; }

    public static String cur(UUID u) { return Db.p(u).getString("job"); }

    public static boolean is(UUID u, String job) { return cur(u).equals(job); }

    public static int level(UUID u) { return 1 + (int) Math.sqrt(Db.p(u).getInt("jxp") / 25.0); }

    /** Plateste pe actiune, doar daca jucatorul are jobul respectiv. Aplica nivel, eveniment si impozit. */
    public static void reward(ServerPlayer p, String job, long base, String why) {
        UUID u = p.getUUID();
        if (!is(u, job)) return;
        double mult = (1 + 0.05 * (level(u) - 1)) * Social.payMult();
        long gross = Math.max(1, Math.round(base * mult));
        long tax = Math.round(gross * Cfg.I.incomeTax);
        City.budget(tax, "Impozit pe venit");
        Bank.add(u, gross - tax, why);
        Db.p(u).putInt("jxp", Db.p(u).getInt("jxp") + (int) Math.max(1, base / 2));
        Util.bar(p, "§a+" + Util.fmt(gross - tax) + " §7(" + name(job) + " nv." + level(u) + ")");
        Social.addRep(u, 1);
    }

    public static void onBreak(ServerPlayer p, BlockState s) {
        Block b = s.getBlock();
        String id = Util.key(b.asItem());
        if (id.contains("_ore") || id.equals("minecraft:stone") || id.equals("minecraft:deepslate") || id.equals("minecraft:cobblestone")) {
            reward(p, "miner", id.contains("diamond") || id.contains("emerald") ? 8 : id.contains("_ore") ? 4 : 2, "Job miner");
        } else if (id.endsWith("_log")) {
            reward(p, "lumberjack", 3, "Job tăietor");
        } else if (b instanceof CropBlock c && c.isMaxAge(s)) {
            reward(p, "farmer", 3, "Job fermier");
        } else if ((b == Blocks.PUMPKIN || b == Blocks.MELON || b == Blocks.SUGAR_CANE)) {
            reward(p, "farmer", 3, "Job fermier");
        }
    }

    public static void onFish(ServerPlayer p) { reward(p, "fisher", 10, "Job pescar"); }

    // ---------------- salarii ----------------
    public static void payday(MinecraftServer s) {
        for (ServerPlayer p : s.getPlayerList().getPlayers()) {
            Integer sal = Cfg.I.salaries.get(cur(p.getUUID()));
            if (sal == null) continue;
            long pay = Math.round(sal * (1 + 0.05 * (level(p.getUUID()) - 1)) * Social.payMult());
            if (City.budgetPay(pay, "Salariu " + name(cur(p.getUUID())) + " " + p.getName().getString())) {
                Bank.add(p.getUUID(), pay, "Salariu " + name(cur(p.getUUID())));
                Util.msg(p, "§a[Salariu] Ai primit " + Util.fmt(pay) + " din bugetul orașului.");
            } else {
                Util.msg(p, "§c[Salariu] Bugetul orașului nu are fonduri pentru salariul tău!");
            }
        }
    }

    // ---------------- meniu ----------------
    public static void menu(ServerPlayer p) {
        UUID u = p.getUUID();
        Ui ui = Ui.of("§aAgenția de joburi")
            .line("§7Jobul tău: §f" + name(cur(u)) + " §7(nv. " + level(u) + ", XP " + Db.p(u).getInt("jxp") + ")");
        for (Map.Entry<String, String[]> e : ALL.entrySet()) {
            ui.line("§e" + e.getValue()[0] + " §7- " + e.getValue()[1]);
            if (!cur(u).equals(e.getKey())) ui.btn("Angajează-te: " + e.getValue()[0], "job:join", "j", e.getKey());
        }
        if (!cur(u).isEmpty()) ui.btn("§cDemisionează", "job:quit");
        ui.btn("Contracte de livrare", "ctr:menu").send(p);
    }

    public static void act(ServerPlayer p, String s, CompoundTag d) {
        UUID u = p.getUUID();
        switch (s) {
            case "join" -> {
                String j = Util.str(d, "j");
                if (ALL.containsKey(j)) {
                    if (j.equals("police") && !Util.op(p) && Db.p(u).getInt("rep") < 5) { Util.msg(p, "§cPoliția cere reputație minimă 5 (sau aprobarea unui admin)."); }
                    else { Db.p(u).putString("job", j); Util.msg(p, "§aAcum ești: " + name(j)); Bank.sync(u); }
                }
            }
            case "quit" -> { Db.p(u).putString("job", ""); Bank.sync(u); }
            default -> { }
        }
        menu(p);
    }
}
