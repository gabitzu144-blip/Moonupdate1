package ro.mooncity.x.feat;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import ro.mooncity.x.*;

import java.util.UUID;

/** Sete 0-100: scade in timp (mai repede la sprint), se umple band lichide. La 0 faci damage. */
@Mod.EventBusSubscriber(modid = MoonX.ID)
public class Thirst {
    public static int get(UUID u) {
        CompoundTag r = Db.p(u);
        return r.contains("thirst") ? r.getInt("thirst") : 100;
    }

    public static void add(ServerPlayer p, int n) {
        CompoundTag r = Db.p(p.getUUID());
        int v = Math.max(0, Math.min(100, get(p.getUUID()) + n));
        if (v != get(p.getUUID())) { r.putInt("thirst", v); Db.dirty(); Bank.sync(p.getUUID()); }
    }

    /** Apelat la fiecare 20 tick-uri (1 secunda). */
    public static void tick(ServerPlayer p) {
        if (p.isCreative() || p.isSpectator()) return;
        CompoundTag r = Db.p(p.getUUID());
        int acc = r.getInt("thirstAcc") + (p.isSprinting() ? 2 : 1);
        if (acc >= 40) { acc = 0; add(p, -1); }
        r.putInt("thirstAcc", acc);
        if (get(p.getUUID()) == 0) {
            int h = r.getInt("thirstHurt") + 1;
            if (h >= 10) { h = 0; p.hurt(p.damageSources().starve(), 1f); Util.bar(p, "§cEști deshidratat! Bea apă."); }
            r.putInt("thirstHurt", h);
        }
    }

    @SubscribeEvent
    public static void drank(LivingEntityUseItemEvent.Finish e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        ItemStack s = e.getItem();
        int n = 0;
        if (s.is(Items.POTION)) n = 35;
        else if (s.is(Items.MILK_BUCKET)) n = 50;
        else if (s.is(Items.HONEY_BOTTLE)) n = 20;
        else if (s.is(Items.MELON_SLICE)) n = 10;
        else if (s.is(Items.APPLE) || s.is(Items.SWEET_BERRIES)) n = 5;
        if (n > 0) add(p, n);
    }
}
