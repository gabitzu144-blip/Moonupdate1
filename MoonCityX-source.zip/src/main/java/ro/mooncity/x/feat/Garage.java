package ro.mooncity.x.feat;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.block.state.BlockState;
import ro.mooncity.x.*;

import java.util.Optional;
import java.util.UUID;

/** Garaj: parchezi masina cu un click (se salveaza tot NBT-ul: culoare, motor, benzina) si o scoti direct, fara bloc de pus. Functioneaza cu orice entitate-vehicul (MrCrayfish, MoonVehicles, Immersive Vehicles). */
public class Garage {
    static ListTag cars(UUID u) { return Db.list(Db.p(u), "garage"); }

    public static boolean store(ServerPlayer owner, Entity v, boolean silent) {
        ListTag g = cars(owner.getUUID());
        if (g.size() >= Cfg.I.garageSlots) { if (!silent) Util.msg(owner, "§cGaraj plin (" + Cfg.I.garageSlots + " locuri)."); return false; }
        v.ejectPassengers();
        CompoundTag t = new CompoundTag();
        if (!v.saveAsPassenger(t)) { if (!silent) Util.msg(owner, "§cAceastă entitate nu poate fi parcată."); return false; }
        CompoundTag rec = new CompoundTag();
        rec.putString("name", v.getType().getDescription().getString());
        rec.put("nbt", t);
        g.add(rec);
        v.discard();
        Db.dirty();
        return true;
    }

    public static void act(ServerPlayer p, String s, CompoundTag d) {
        UUID u = p.getUUID();
        ServerLevel lvl = p.serverLevel();
        BlockPos at = d.contains("pos") ? BlockPos.of(d.getLong("pos")) : p.blockPosition();
        switch (s) {
            case "block" -> { }
            case "store" -> {
                Entity v = Util.nearestVehicleAt(lvl, at, 12);
                if (v == null) Util.msg(p, "§cNicio mașină în apropiere (12 blocuri).");
                else {
                    UUID o = Util.owner(v);
                    if (o != null && !o.equals(u) && !Util.op(p)) Util.msg(p, "§cMașina aparține lui " + Db.name(o) + ".");
                    else if (store(p, v, false)) Util.msg(p, "§aMașina a fost parcată în garaj.");
                }
            }
            case "out" -> {
                ListTag g = cars(u);
                int i = d.getInt("i");
                if (i >= 0 && i < g.size()) {
                    CompoundTag rec = g.getCompound(i);
                    BlockState bs = lvl.getBlockState(at);
                    Direction f = bs.hasProperty(net.minecraft.world.level.block.HorizontalDirectionalBlock.FACING)
                        ? bs.getValue(net.minecraft.world.level.block.HorizontalDirectionalBlock.FACING) : Direction.NORTH;
                    BlockPos sp = at.relative(f, 3);
                    CompoundTag nbt = rec.getCompound("nbt").copy();
                    Optional<Entity> e = EntityType.create(nbt, lvl);
                    if (e.isEmpty()) Util.msg(p, "§cNu pot scoate mașina (tip lipsă?).");
                    else {
                        Entity v = e.get();
                        v.setUUID(UUID.randomUUID());
                        v.moveTo(sp.getX() + .5, sp.getY() + .1, sp.getZ() + .5, f.toYRot(), 0f);
                        v.getPersistentData().putString("moon_owner", u.toString());
                        v.getPersistentData().putInt("moon_idle", 0);
                        lvl.addFreshEntity(v);
                        g.remove(i);
                        Db.dirty();
                        Util.msg(p, "§aMașina a fost scoasă în fața garajului.");
                    }
                }
            }
            default -> { }
        }
        menu(p, at);
    }

    static void menu(ServerPlayer p, BlockPos at) {
        ListTag g = cars(p.getUUID());
        CompoundTag at0 = new CompoundTag();
        at0.putLong("pos", at.asLong());
        Ui u = Ui.of("§6Garajul tău").line("§7Locuri: §f" + g.size() + "/" + Cfg.I.garageSlots)
            .btn("Parchează mașina din apropiere", "garage:store", at0);
        for (int i = 0; i < g.size(); i++) {
            CompoundTag rec = g.getCompound(i);
            CompoundTag d = new CompoundTag();
            d.putInt("i", i);
            d.putLong("pos", at.asLong());
            CompoundTag n = rec.getCompound("nbt");
            u.btn("Scoate: " + rec.getString("name") + "", "garage:out", d);
        }
        u.line("§8Mașinile lăsate afară >" + Cfg.I.abandonMinutes + " min intră automat aici.").send(p);
    }

    // verificare mașini abandonate (apelat la ~20s)
    public static void scan(net.minecraft.server.MinecraftServer srv) {
        for (ServerLevel l : srv.getAllLevels()) {
            java.util.List<Entity> list = new java.util.ArrayList<>();
            for (Entity e : l.getAllEntities()) if (Util.isVehicle(e)) list.add(e);
            for (Entity e : list) {
                CompoundTag pd = e.getPersistentData();
                if (!e.getPassengers().isEmpty()) {
                    pd.putInt("moon_idle", 0);
                    for (Entity pa : e.getPassengers()) if (pa instanceof ServerPlayer sp && !pd.contains("moon_owner")) {
                        pd.putString("moon_owner", sp.getUUID().toString());
                        Util.bar(sp, "§aVehicul înregistrat pe numele tău.");
                    }
                    continue;
                }
                UUID o = Util.owner(e);
                if (o == null) continue;
                int idle = pd.getInt("moon_idle") + 400;
                pd.putInt("moon_idle", idle);
                if (idle >= Cfg.I.abandonMinutes * 1200) {
                    ServerPlayer op = Util.online(o);
                    if (op != null) { if (store(op, e, true)) Util.msg(op, "§e[Garaj] Mașina ta lăsată afară a fost parcată automat."); }
                    else { // proprietar offline: o parcam direct in garajul lui
                        ListTag g = cars(o);
                        if (g.size() < Cfg.I.garageSlots) {
                            CompoundTag t = new CompoundTag();
                            e.ejectPassengers();
                            if (e.saveAsPassenger(t)) { CompoundTag rec = new CompoundTag(); rec.putString("name", e.getType().getDescription().getString()); rec.put("nbt", t); g.add(rec); e.discard(); Db.dirty(); }
                        }
                    }
                }
            }
        }
    }
}
