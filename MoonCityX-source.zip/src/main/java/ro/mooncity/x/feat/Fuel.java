package ro.mooncity.x.feat;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import ro.mooncity.x.*;

import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/** MoonFuel: pompa de benzina. O singura masina (cea mai apropiata, max. 7 blocuri) se alimenteaza automat, platita de pe card. */
public class Fuel {
    static ListTag pumps() { return Db.slist(Db.sec("meta"), "pumps"); }

    public static void register(ServerLevel l, BlockPos p) {
        String k = Util.posKey(l, p);
        ListTag t = pumps();
        for (int i = 0; i < t.size(); i++) if (t.getString(i).equals(k)) return;
        t.add(net.minecraft.nbt.StringTag.valueOf(k));
        Db.dirty();
    }

    public static void unregister(ServerLevel l, BlockPos p) {
        String k = Util.posKey(l, p);
        ListTag t = pumps();
        for (int i = t.size() - 1; i >= 0; i--) if (t.getString(i).equals(k)) t.remove(i);
        Db.dirty();
    }

    public static void act(ServerPlayer p, String s, CompoundTag d) {
        Ui.of("§6MoonFuel – pompă")
            .line("§7Parchează mașina la maxim " + Cfg.I.fuelRange + " blocuri de pompă.")
            .line("§7Se alimentează automat; plata se ia de pe cardul tău.")
            .line("§7Preț: §f" + Cfg.I.fuelPrice + " RON / unitate. Doar o mașină odată (cea mai apropiată).")
            .send(p);
    }

    /** La fiecare 10 tick-uri. */
    public static void tick(MinecraftServer srv) {
        ListTag t = pumps();
        for (int i = 0; i < t.size(); i++) {
            String[] a = t.getString(i).split("\\|");
            if (a.length != 2) continue;
            String[] c = a[1].split(",");
            BlockPos pos = new BlockPos(Integer.parseInt(c[0]), Integer.parseInt(c[1]), Integer.parseInt(c[2]));
            ServerLevel l = null;
            for (ServerLevel x : srv.getAllLevels()) if (x.dimension().location().toString().equals(a[0])) l = x;
            if (l == null || !l.isLoaded(pos)) continue;
            double r = Cfg.I.fuelRange;
            List<Entity> v = l.getEntities((Entity) null, new AABB(pos).inflate(r), Veh::powered);
            Entity car = v.stream().min(Comparator.comparingDouble(e -> e.distanceToSqr(pos.getX() + .5, pos.getY(), pos.getZ() + .5))).orElse(null);
            if (car == null) continue;
            float fuel = Veh.fuel(car), cap = Veh.cap(car);
            if (cap <= 0 || fuel >= cap - 0.4f) continue;
            ServerPlayer payer = null;
            UUID o = Util.owner(car);
            if (o != null) payer = Util.online(o);
            if (payer == null) for (Entity pa : car.getPassengers()) if (pa instanceof ServerPlayer sp) payer = sp;
            if (payer == null) {
                ServerPlayer near = null;
                for (ServerPlayer sp : l.players()) if (sp.distanceToSqr(pos.getX() + .5, pos.getY(), pos.getZ() + .5) < 100) near = sp;
                payer = near;
            }
            if (payer == null) continue;
            float add = Math.min(cap - fuel, Cfg.I.fuelPerSecond / 2f);
            CompoundTag pd = car.getPersistentData();
            double debt = pd.getDouble("moon_fdebt") + add * Cfg.I.fuelPrice;
            long charge = (long) Math.floor(debt);
            if (charge > 0 && !Bank.take(payer.getUUID(), charge, "MoonFuel")) {
                Util.bar(payer, "§c⛽ Fonduri insuficiente pe card pentru combustibil!");
                continue;
            }
            pd.putDouble("moon_fdebt", debt - charge);
            Veh.setFuel(car, fuel + add);
            Util.bar(payer, "§a⛽ Alimentare: " + Math.round(fuel + add) + "/" + Math.round(cap));
        }
    }
}
