package ro.mooncity.x.feat;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import ro.mooncity.x.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/** MoonBank: cont personal, bani fizici (bancnote RON), card, transferuri, extras de cont, conturi pentru firme. */
public class Bank {
    static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("dd.MM HH:mm");

    // ---------------- API ----------------
    public static long bal(UUID u) { return Db.p(u).getLong("bank"); }

    public static String iban(UUID u) { int id = Db.id(u); return String.format("RO%02dMOON%016d", (id * 7) % 100, id); }

    public static void log(UUID u, String line) { Db.addStr(Db.slist(Db.p(u), "hist"), LocalDateTime.now().format(TS) + "  " + line, 60); }

    public static boolean take(UUID u, long amt, String why) {
        if (amt < 0) return false;
        CompoundTag r = Db.p(u);
        if (r.getLong("bank") < amt) return false;
        r.putLong("bank", r.getLong("bank") - amt);
        if (amt > 0) log(u, "-" + Util.fmt(amt) + "  " + why);
        sync(u);
        return true;
    }

    public static void add(UUID u, long amt, String why) {
        if (amt <= 0) return;
        CompoundTag r = Db.p(u);
        r.putLong("bank", r.getLong("bank") + amt);
        log(u, "+" + Util.fmt(amt) + "  " + why);
        sync(u);
    }

    public static void sync(UUID u) {
        ServerPlayer p = Util.online(u);
        if (p == null) return;
        CompoundTag r = Db.p(u), t = new CompoundTag();
        t.putInt("id", r.getInt("id"));
        t.putLong("bank", r.getLong("bank"));
        t.putString("job", Jobs.name(r.getString("job")));
        t.putInt("rep", r.getInt("rep"));
        t.putInt("hud", r.getInt("hud"));
        t.putLong("cash", cash(p));
        Net.to(p, "sync", t);
    }

    // ---------------- numerar fizic ----------------
    public static long cash(ServerPlayer p) {
        long n = 0;
        for (var e : Reg.MONEY.entrySet()) n += (long) e.getKey() * Util.count(p, Util.key(e.getValue().get()));
        return n;
    }

    public static boolean takeCash(ServerPlayer p, long amt) {
        if (amt <= 0 || cash(p) < amt) return false;
        // scoatem bancnotele de la mari la mici pana acoperim suma, restul il dam inapoi
        long left = amt;
        List<Integer> vals = new ArrayList<>(Reg.MONEY.keySet());
        vals.sort(Comparator.reverseOrder());
        for (int v : vals) {
            String id = Util.key(Reg.MONEY.get(v).get());
            int have = Util.count(p, id);
            int use = (int) Math.min(have, left / v);
            if (use > 0) { Util.remove(p, id, use); left -= (long) use * v; }
        }
        if (left > 0) { // trebuie spartata o bancnota mai mare
            for (int i = vals.size() - 1; i >= 0 && left > 0; i--) {
                int v = vals.get(i);
                String id = Util.key(Reg.MONEY.get(v).get());
                if (Util.count(p, id) > 0) { Util.remove(p, id, 1); giveCash(p, v - left); left = 0; }
            }
        }
        return left == 0;
    }

    public static void giveCash(ServerPlayer p, long amt) {
        List<Integer> vals = new ArrayList<>(Reg.MONEY.keySet());
        vals.sort(Comparator.reverseOrder());
        for (int v : vals) {
            long n = amt / v;
            amt -= n * v;
            while (n > 0) { int s = (int) Math.min(64, n); Util.give(p, new ItemStack(Reg.MONEY.get(v).get(), s)); n -= s; }
        }
    }

    /** Plata: intai numerar, apoi card (setarea "pay" = 1 inseamna doar card). */
    public static boolean pay(ServerPlayer p, long amt, String why) {
        if (amt <= 0) return true;
        boolean cardOnly = Db.p(p.getUUID()).getInt("pay") == 1;
        if (!cardOnly && takeCash(p, amt)) return true;
        return take(p.getUUID(), amt, why);
    }

    // ---------------- meniuri ----------------
    public static void act(ServerPlayer p, String s, CompoundTag d) {
        UUID u = p.getUUID();
        CompoundTag r = Db.p(u);
        switch (s) {
            case "atm", "main" -> main(p);
            case "dep" -> { long a = Util.num(d, "amt"); deposit(p, a); main(p); }
            case "depall" -> { deposit(p, cash(p)); main(p); }
            case "wd" -> { long a = Util.num(d, "amt"); withdraw(p, a); main(p); }
            case "tr" -> { transfer(p, Util.str(d, "to"), Util.num(d, "amt"), Util.str(d, "note")); main(p); }
            case "stmt" -> stmt(p);
            case "card" -> {
                if (!take(u, Cfg.I.bankCardPrice, "Card bancar nou")) { Util.msg(p, "§cNu ai destui bani în cont."); }
                else { Util.give(p, Docs.card(u)); Util.msg(p, "§aAi primit un card nou."); }
                main(p);
            }
            case "biz" -> biz(p);
            case "bizc" -> {
                String n = Util.str(d, "name");
                if (n.length() < 3) { Util.msg(p, "§cNume prea scurt."); biz(p); return; }
                if (!take(u, Cfg.I.bizPrice, "Deschidere cont firmă " + n)) { Util.msg(p, "§cFonduri insuficiente."); biz(p); return; }
                CompoundTag b = Db.sec("biz");
                int next = Db.sec("meta").getInt("nextBiz") + 1;
                Db.sec("meta").putInt("nextBiz", next);
                CompoundTag nb = new CompoundTag();
                nb.putString("name", n);
                nb.putString("owner", u.toString());
                nb.putLong("bal", 0);
                nb.put("mem", new ListTag());
                nb.put("hist", new ListTag());
                b.put(String.valueOf(next), nb);
                Db.dirty();
                biz(p);
            }
            case "bizv" -> bizView(p, (int) Util.num(d, "b"));
            case "bizdep" -> bizMove(p, (int) Util.num(d, "b"), Util.num(d, "amt"), true);
            case "bizwd" -> bizMove(p, (int) Util.num(d, "b"), Util.num(d, "amt"), false);
            case "bizpay" -> {
                int b = (int) Util.num(d, "b");
                CompoundTag bz = Db.sec("biz").getCompound(String.valueOf(b));
                UUID t = Db.find(Util.str(d, "to"));
                long a = Util.num(d, "amt");
                if (bz.isEmpty() || !isMember(bz, u) || t == null || a <= 0 || bz.getLong("bal") < a) { Util.msg(p, "§cTranzacție invalidă."); }
                else { bz.putLong("bal", bz.getLong("bal") - a); bizLog(bz, "-" + Util.fmt(a) + " către " + Db.name(t)); add(t, a, "Plată de la " + bz.getString("name")); Util.msg(p, "§aPlătit."); }
                Db.dirty();
                bizView(p, b);
            }
            case "bizadd" -> {
                int b = (int) Util.num(d, "b");
                CompoundTag bz = Db.sec("biz").getCompound(String.valueOf(b));
                UUID t = Db.find(Util.str(d, "who"));
                if (bz.isEmpty() || !bz.getString("owner").equals(u.toString()) || t == null) Util.msg(p, "§cNu poți adăuga.");
                else { Db.addStr(Db.slist(bz, "mem"), t.toString(), 50); Util.msg(p, "§aAdăugat " + Db.name(t)); Db.dirty(); }
                bizView(p, b);
            }
            default -> main(p);
        }
    }

    static void main(ServerPlayer p) {
        UUID u = p.getUUID();
        Ui.of("§5§lMoonBank")
            .line("§7Titular: §f" + p.getName().getString() + " §7(ID " + Db.id(u) + ")")
            .line("§7IBAN: §f" + iban(u))
            .line("§7Cont: §a" + Util.fmt(bal(u)) + "  §7Numerar la tine: §e" + Util.fmt(cash(p)))
            .sep()
            .in("amt", "Suma (RON)", "100")
            .btn("Depune suma", "bank:dep")
            .btn("Depune tot numerarul", "bank:depall")
            .btn("Retrage suma (bancnote)", "bank:wd")
            .sep()
            .in("to", "Transfer către (ID / nume / B<nr firma>)", "")
            .in("note", "Descriere", "")
            .btn("Trimite transfer (suma de sus)", "bank:tr")
            .sep()
            .btn("Extras de cont", "bank:stmt")
            .btn("Conturi firmă", "bank:biz")
            .btn("Card bancar nou (" + Cfg.I.bankCardPrice + " RON)", "bank:card")
            .send(p);
    }

    static void deposit(ServerPlayer p, long a) {
        if (a <= 0 || !takeCash(p, a)) { Util.msg(p, "§cNu ai atâta numerar."); return; }
        add(p.getUUID(), a, "Depunere numerar");
        Util.msg(p, "§aAi depus " + Util.fmt(a));
    }

    static void withdraw(ServerPlayer p, long a) {
        if (a <= 0 || a > 1_000_000 || !take(p.getUUID(), a, "Retragere numerar")) { Util.msg(p, "§cSumă invalidă sau fonduri insuficiente."); return; }
        giveCash(p, a);
        Util.msg(p, "§aAi retras " + Util.fmt(a));
    }

    static void transfer(ServerPlayer p, String to, long a, String note) {
        UUID u = p.getUUID();
        if (a <= 0) { Util.msg(p, "§cSumă invalidă."); return; }
        if (to.toUpperCase().startsWith("B")) {
            String bid = to.substring(1).trim();
            CompoundTag bz = Db.sec("biz").getCompound(bid);
            if (bz.isEmpty() || !take(u, a, "Transfer către firma " + bz.getString("name"))) { Util.msg(p, "§cTransfer eșuat."); return; }
            bz.putLong("bal", bz.getLong("bal") + a);
            bizLog(bz, "+" + Util.fmt(a) + " de la " + p.getName().getString() + (note.isEmpty() ? "" : " (" + note + ")"));
            Db.dirty();
            Util.msg(p, "§aTrimis " + Util.fmt(a));
            return;
        }
        UUID t = Db.find(to);
        if (t == null || t.equals(u)) { Util.msg(p, "§cDestinatar invalid."); return; }
        if (!take(u, a, "Transfer către " + Db.name(t) + " (ID " + Db.id(t) + ")" + (note.isEmpty() ? "" : " - " + note))) { Util.msg(p, "§cFonduri insuficiente."); return; }
        add(t, a, "Transfer de la " + p.getName().getString() + (note.isEmpty() ? "" : " - " + note));
        ServerPlayer tp = Util.online(t);
        if (tp != null) Util.msg(tp, "§a[Bancă] Ai primit " + Util.fmt(a) + " de la " + p.getName().getString());
        Util.msg(p, "§aTransfer reușit: " + Util.fmt(a) + " → " + Db.name(t));
    }

    static void stmt(ServerPlayer p) {
        Ui u = Ui.of("§5Extras de cont").line("§7Sold: §a" + Util.fmt(bal(p.getUUID())));
        ListTag h = Db.slist(Db.p(p.getUUID()), "hist");
        for (int i = h.size() - 1; i >= 0 && i >= h.size() - 25; i--) u.line("§f" + h.getString(i));
        u.btn("« Înapoi", "bank:main").send(p);
    }

    // ---------------- firme ----------------
    static boolean isMember(CompoundTag bz, UUID u) {
        if (bz.getString("owner").equals(u.toString())) return true;
        ListTag m = bz.getList("mem", Tag.TAG_STRING);
        for (int i = 0; i < m.size(); i++) if (m.getString(i).equals(u.toString())) return true;
        return false;
    }

    static void bizLog(CompoundTag bz, String s) { Db.addStr(Db.slist(bz, "hist"), LocalDateTime.now().format(TS) + "  " + s, 40); }

    static void biz(ServerPlayer p) {
        Ui u = Ui.of("§5Conturi firmă").line("§7Firmele la care ai acces:");
        CompoundTag all = Db.sec("biz");
        for (String k : all.getAllKeys()) {
            CompoundTag b = all.getCompound(k);
            if (isMember(b, p.getUUID())) u.btn("B" + k + " • " + b.getString("name") + " • " + Util.fmt(b.getLong("bal")), "bank:bizv", "b", k);
        }
        u.sep().in("name", "Nume firmă nouă (" + Cfg.I.bizPrice + " RON)", "").btn("Deschide cont firmă", "bank:bizc").btn("« Înapoi", "bank:main").send(p);
    }

    static void bizView(ServerPlayer p, int id) {
        CompoundTag bz = Db.sec("biz").getCompound(String.valueOf(id));
        if (bz.isEmpty() || !isMember(bz, p.getUUID())) { biz(p); return; }
        boolean owner = bz.getString("owner").equals(p.getUUID().toString());
        Ui u = Ui.of("§5" + bz.getString("name") + " §7(B" + id + ")")
            .line("§7Sold firmă: §a" + Util.fmt(bz.getLong("bal")))
            .line("§7Proprietar: §f" + Db.name(UUID.fromString(bz.getString("owner"))))
            .in("amt", "Suma", "100");
        CompoundTag b = new CompoundTag();
        b.putString("b", String.valueOf(id));
        u.btn("Depune din contul personal", "bank:bizdep", b);
        if (owner) u.btn("Retrage în contul personal", "bank:bizwd", b);
        u.in("to", "Plătește către (ID/nume)", "").btn("Plătește din firmă", "bank:bizpay", b);
        if (owner) u.in("who", "Adaugă membru (ID/nume)", "").btn("Adaugă membru", "bank:bizadd", b);
        u.sep().line("§7Extras firmă:");
        ListTag h = bz.getList("hist", Tag.TAG_STRING);
        for (int i = h.size() - 1; i >= 0 && i >= h.size() - 10; i--) u.line("§f" + h.getString(i));
        u.btn("« Firme", "bank:biz").send(p);
    }

    static void bizMove(ServerPlayer p, int id, long a, boolean dep) {
        CompoundTag bz = Db.sec("biz").getCompound(String.valueOf(id));
        UUID u = p.getUUID();
        if (bz.isEmpty() || a <= 0) { Util.msg(p, "§cSumă invalidă."); return; }
        if (dep) {
            if (!isMember(bz, u) || !take(u, a, "Depunere în firma " + bz.getString("name"))) { Util.msg(p, "§cFonduri insuficiente."); }
            else { bz.putLong("bal", bz.getLong("bal") + a); bizLog(bz, "+" + Util.fmt(a) + " depunere " + p.getName().getString()); }
        } else {
            if (!bz.getString("owner").equals(u.toString()) || bz.getLong("bal") < a) { Util.msg(p, "§cNu poți retrage."); }
            else { bz.putLong("bal", bz.getLong("bal") - a); bizLog(bz, "-" + Util.fmt(a) + " retragere"); add(u, a, "Retragere din firma " + bz.getString("name")); }
        }
        Db.dirty();
        bizView(p, id);
    }

    public static boolean bizPay(int id, long a, String why) {
        CompoundTag bz = Db.sec("biz").getCompound(String.valueOf(id));
        if (bz.isEmpty() || bz.getLong("bal") < a) return false;
        bz.putLong("bal", bz.getLong("bal") - a);
        bizLog(bz, "-" + Util.fmt(a) + " " + why);
        Db.dirty();
        return true;
    }

    public static void bizCredit(int id, long a, String why) {
        CompoundTag bz = Db.sec("biz").getCompound(String.valueOf(id));
        if (bz.isEmpty()) return;
        bz.putLong("bal", bz.getLong("bal") + a);
        bizLog(bz, "+" + Util.fmt(a) + " " + why);
        Db.dirty();
    }
}
