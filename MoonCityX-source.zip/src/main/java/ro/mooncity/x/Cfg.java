package ro.mooncity.x;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.minecraftforge.fml.loading.FMLPaths;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/** Configurare JSON: config/mooncityx.json (se creeaza automat; editeaza-l liber). */
public class Cfg {
    public static Cfg I = new Cfg();

    // --- masini ---
    public boolean enforceLicense = true;          // nu poti conduce fara permis
    public List<String> hiddenOverlays = new ArrayList<>(List.of("mooncityvehicles:speedometer")); // HUD-uri ascunse
    public List<String> vehicleNamespaces = new ArrayList<>(List.of("vehicle", "mooncityvehicles", "mts", "iv", "immersivevehicles", "immersive_vehicles", "mrcrayfish_vehicle"));
    public float speedMultiplier = 1.8f;           // viteza maxima x (peste 100 km/h)
    public float accelMultiplier = 1.4f;
    public int garageSlots = 12;
    public int abandonMinutes = 10;                // masina lasata afara -> intra automat in garajul soferului
    // --- combustibil ---
    public double fuelPrice = 6.5;                 // RON / unitate
    public int fuelRange = 7;                      // blocuri (o singura masina, cea mai apropiata)
    public float fuelPerSecond = 25f;
    // --- taxi ---
    public int taxiStart = 8;
    public double taxiPerKm = 3.5;
    public double taxiCompanyCut = 0.10;
    // --- taxe / preturi ---
    public double vat = 0.19;
    public double incomeTax = 0.10;
    public int idCardPrice = 100, licensePrice = 200, examPrice = 250, bankCardPrice = 20, bizPrice = 2000, shopListFee = 0;
    public int adPrice = 50, candidateFee = 1000, territoryPrice = 5000, territoryIncomePerHour = 150, contestFee = 2000;
    public int busTicket = 5, medConsult = 150, medkitPrice = 120, bandagePrice = 30;
    public int paydayMinutes = 20;
    public int maxBet = 50000;
    // --- salarii la payday (din bugetul orasului) ---
    public Map<String, Integer> salaries = new LinkedHashMap<>(Map.of("police", 600, "medic", 500, "bus", 350, "mechanic", 300, "instructor", 300));
    // --- NPC vanzare: item -> RON / bucata (se plateste in banca) ---
    public Map<String, Integer> sell = new LinkedHashMap<>();
    // --- pret de baza la magazine (pentru limite min/max si aprovizionare la 55%) ---
    public Map<String, Integer> shopBase = new LinkedHashMap<>();

    public Cfg() {
        String[][] s = {
            {"minecraft:wheat", "6"}, {"minecraft:carrot", "5"}, {"minecraft:potato", "5"}, {"minecraft:beetroot", "5"},
            {"minecraft:cod", "12"}, {"minecraft:salmon", "18"}, {"minecraft:tropical_fish", "40"}, {"minecraft:pufferfish", "35"},
            {"minecraft:coal", "10"}, {"minecraft:raw_iron", "22"}, {"minecraft:raw_copper", "12"}, {"minecraft:raw_gold", "60"},
            {"minecraft:iron_ingot", "30"}, {"minecraft:gold_ingot", "80"}, {"minecraft:diamond", "400"}, {"minecraft:emerald", "250"},
            {"minecraft:oak_log", "6"}, {"minecraft:spruce_log", "6"}, {"minecraft:birch_log", "6"}, {"minecraft:cobblestone", "1"},
            {"minecraft:leather", "9"}, {"minecraft:egg", "3"}, {"minecraft:beef", "14"}, {"minecraft:porkchop", "13"},
            {"minecraft:chicken", "11"}, {"minecraft:milk_bucket", "20"}, {"minecraft:sugar_cane", "4"}, {"minecraft:pumpkin", "9"}
        };
        for (String[] a : s) sell.put(a[0], Integer.parseInt(a[1]));
        String[][] b = {
            {"minecraft:bread", "15"}, {"minecraft:apple", "8"}, {"minecraft:cooked_beef", "28"}, {"minecraft:cooked_chicken", "22"},
            {"minecraft:cooked_cod", "20"}, {"minecraft:cookie", "6"}, {"minecraft:cake", "60"}, {"minecraft:golden_carrot", "45"},
            {"minecraft:torch", "4"}, {"minecraft:bucket", "40"}, {"minecraft:fishing_rod", "90"}, {"minecraft:iron_pickaxe", "180"},
            {"minecraft:iron_axe", "170"}, {"minecraft:shears", "70"}, {"minecraft:name_tag", "150"}, {"minecraft:lead", "50"},
            {"minecraft:white_wool", "20"}, {"minecraft:glass", "10"}, {"minecraft:paper", "6"}, {"minecraft:book", "40"},
            {"mooncityx:medkit", "120"}, {"mooncityx:bandage", "30"}, {"minecraft:potion", "35"}
        };
        for (String[] a : b) shopBase.put(a[0], Integer.parseInt(a[1]));
    }

    static Path file() { return FMLPaths.CONFIGDIR.get().resolve("mooncityx.json"); }

    public static void load() {
        Gson g = new GsonBuilder().setPrettyPrinting().create();
        Path f = file();
        try {
            if (Files.exists(f)) {
                try (Reader r = Files.newBufferedReader(f)) {
                    Cfg c = g.fromJson(r, Cfg.class);
                    if (c != null) I = c;
                }
            }
            try (Writer w = Files.newBufferedWriter(f)) { g.toJson(I, w); } // rescrie cu campuri noi
        } catch (Exception e) {
            MoonX.LOG.error("Nu pot citi config mooncityx.json, folosesc valorile implicite", e);
        }
    }
}
