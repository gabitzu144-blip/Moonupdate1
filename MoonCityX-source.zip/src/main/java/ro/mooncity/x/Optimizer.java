package ro.mooncity.x;

import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** MoonOptimize (server): sterge iteme vechi, plafoneaza mobii naturali, se strange singur cand serverul lagareste. */
@Mod.EventBusSubscriber(modid = MoonX.ID)
public class Optimizer {
    static volatile int mobs, items;
    static volatile boolean lagging;
    static volatile float mspt;

    /** Apelat la ~10 secunde. O singura trecere peste entitati. */
    public static void scan(MinecraftServer s) {
        if (!Cfg.I.optEnabled) return;
        mspt = s.getAverageTickTime();
        lagging = mspt > Cfg.I.optLagMspt;
        // cand lagareste, itemele traiesc de 3 ori mai putin
        long maxAge = Cfg.I.optItemMaxAgeSec * 20L / (lagging ? 3 : 1);
        int m = 0, it = 0;
        for (ServerLevel l : s.getAllLevels()) {
            for (Entity e : l.getAllEntities()) {
                if (e instanceof ItemEntity ie) {
                    if (ie.getAge() > maxAge) ie.discard(); else it++;
                } else if (e instanceof Mob mob && !mob.isPersistenceRequired() && !mob.hasCustomName()) m++;
            }
        }
        mobs = m;
        items = it;
    }

    static int clearItems(MinecraftServer s) {
        int n = 0;
        for (ServerLevel l : s.getAllLevels())
            for (Entity e : l.getAllEntities()) if (e instanceof ItemEntity) { e.discard(); n++; }
        items = 0;
        return n;
    }

    /** Blocheaza spawn-urile naturale cand plafonul de mobi e atins (jumatate cand serverul lagareste). */
    @SubscribeEvent
    public static void join(EntityJoinLevelEvent e) {
        if (!Cfg.I.optEnabled || e.getLevel().isClientSide() || e.loadedFromDisk()) return;
        Entity en = e.getEntity();
        if (!(en instanceof Mob mob) || mob.isPersistenceRequired() || mob.hasCustomName()) return;
        if (!(en instanceof Enemy) && !(en instanceof Animal)) return;
        int cap = lagging ? Cfg.I.optMobCap / 2 : Cfg.I.optMobCap;
        if (mobs >= cap) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void cmds(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("moonopt").requires(s -> s.hasPermission(2))
            .executes(c -> {
                float tps = Math.min(20f, 1000f / Math.max(1f, mspt));
                c.getSource().sendSuccess(() -> Component.literal(String.format(
                    "§bMoonOptimize §7• TPS §f%.1f §7• MSPT §f%.1f §7• mobi §f%d/%d §7• iteme §f%d §7• %s",
                    tps, mspt, mobs, Cfg.I.optMobCap, items, lagging ? "§cLAG" : "§aOK")), false);
                return 1;
            })
            .then(Commands.literal("clear").executes(c -> {
                int n = clearItems(c.getSource().getServer());
                c.getSource().sendSuccess(() -> Component.literal("§aAm șters " + n + " iteme de pe jos."), true);
                return n;
            })));
    }
}
