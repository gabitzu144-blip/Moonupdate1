package ro.mooncity.x.item;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import ro.mooncity.x.feat.Jobs;

import java.util.List;

/** Trusa medicala / bandaj. Click = te vindeci; click pe alt jucator = il vindeci (medicii primesc plata). */
public class MedItem extends Item {
    final float heal;
    final int cd;

    public MedItem(float heal, int cd) {
        super(new Item.Properties().stacksTo(16));
        this.heal = heal;
        this.cd = cd;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level l, Player pl, InteractionHand h) {
        ItemStack st = pl.getItemInHand(h);
        if (pl.getHealth() >= pl.getMaxHealth() || pl.getCooldowns().isOnCooldown(this)) return InteractionResultHolder.fail(st);
        if (!l.isClientSide) {
            pl.heal(heal);
            st.shrink(1);
            pl.getCooldowns().addCooldown(this, cd);
        }
        return InteractionResultHolder.sidedSuccess(st, l.isClientSide);
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack st, Player pl, LivingEntity t, InteractionHand h) {
        if (pl.level().isClientSide || t.getHealth() >= t.getMaxHealth() || pl.getCooldowns().isOnCooldown(this)) return InteractionResult.PASS;
        t.heal(heal);
        st.shrink(1);
        pl.getCooldowns().addCooldown(this, cd);
        if (pl instanceof ServerPlayer sp && t instanceof ServerPlayer) Jobs.reward(sp, "medic", 35, "Ai tratat un pacient");
        return InteractionResult.SUCCESS;
    }

    @Override
    public void appendHoverText(ItemStack s, Level l, List<Component> t, TooltipFlag f) {
        t.add(Component.literal("§7Vindecă " + (int) (heal / 2) + " ❤ • Click pe alt jucător = îl tratezi"));
    }
}
