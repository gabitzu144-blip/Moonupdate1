package ro.mooncity.x.item;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

public class MoneyItem extends Item {
    public final int value;

    public MoneyItem(int v) {
        super(new Item.Properties());
        this.value = v;
    }

    @Override
    public void appendHoverText(ItemStack s, Level l, List<Component> t, TooltipFlag f) {
        t.add(Component.literal("§7Bancnotă " + value + " RON (Banca MoonCity)"));
    }
}
