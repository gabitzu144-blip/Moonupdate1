package ro.mooncity.x.item;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import ro.mooncity.x.feat.Docs;

import java.util.List;

/** Buletin / permis / card bancar. Click = il vezi; click pe alt jucator = i-l arati. */
public class DocItem extends Item {
    public final String kind;

    public DocItem(String kind) {
        super(new Item.Properties().stacksTo(1));
        this.kind = kind;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level l, Player pl, InteractionHand h) {
        ItemStack st = pl.getItemInHand(h);
        if (!l.isClientSide && pl instanceof ServerPlayer sp) Docs.show(sp, st);
        return InteractionResultHolder.sidedSuccess(st, l.isClientSide);
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack st, Player pl, LivingEntity target, InteractionHand h) {
        if (!pl.level().isClientSide && target instanceof ServerPlayer tp) {
            Docs.show(tp, st);
            pl.displayClientMessage(Component.literal("§aI-ai arătat documentul lui " + tp.getName().getString()), true);
            return InteractionResult.SUCCESS;
        }
        return InteractionResult.PASS;
    }

    @Override
    public void appendHoverText(ItemStack s, Level l, List<Component> t, TooltipFlag f) {
        CompoundTag d = s.getTag();
        if (d == null) { t.add(Component.literal("§7Document gol")); return; }
        t.add(Component.literal("§7" + d.getString("name") + " • ID " + d.getInt("pid")));
        if (kind.equals("card")) t.add(Component.literal("§8" + d.getString("iban")));
        t.add(Component.literal("§8Click = vezi • Click pe jucător = arată"));
    }
}
