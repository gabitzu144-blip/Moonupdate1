package ro.mooncity.x;

import com.mojang.logging.LogUtils;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(MoonX.ID)
public class MoonX {
    public static final String ID = "mooncityx";
    public static final Logger LOG = LogUtils.getLogger();

    public MoonX() {
        Cfg.load();
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        Reg.init(bus);
        Net.init();
    }
}
