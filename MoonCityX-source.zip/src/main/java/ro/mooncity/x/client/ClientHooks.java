package ro.mooncity.x.client;

import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import ro.mooncity.x.Net;

/** Primeste pachetele S2C si deschide ecranul potrivit. */
public class ClientHooks {
    public static int id, rep, hud, thirst = 100;
    public static float kg, kgMax = 50f;
    public static long bank, cash;
    public static String job = "";

    public record Toast(String title, String text, int color, long until) { }
    public static final java.util.ArrayList<Toast> TOASTS = new java.util.ArrayList<>();
    public static boolean navOn;
    public static int navX, navZ;
    public static String navLabel = "";

    public static void recv(String kind, CompoundTag t) {
        Minecraft mc = Minecraft.getInstance();
        switch (kind) {
            case "close" -> { if (mc.screen instanceof GenericScreen) mc.setScreen(null); }
            case "sync" -> { id = t.getInt("id"); bank = t.getLong("bank"); cash = t.getLong("cash"); job = t.getString("job"); rep = t.getInt("rep"); hud = t.getInt("hud"); thirst = t.contains("thirst") ? t.getInt("thirst") : 100; kg = t.getFloat("kg"); kgMax = t.contains("kgmax") ? t.getFloat("kgmax") : 50f; }
            case "toast" -> {
                TOASTS.add(new Toast(t.getString("t"), t.getString("s"), t.getInt("c"), System.currentTimeMillis() + 4500));
                while (TOASTS.size() > 5) TOASTS.remove(0);
            }
            case "nav" -> { navOn = t.getInt("has") == 1; navX = t.getInt("x"); navZ = t.getInt("z"); navLabel = t.getString("label"); }
            case "menu" -> mc.setScreen(new GenericScreen(t, false));
            case "phone" -> mc.setScreen(new GenericScreen(phone(), false));
            case "tuning" -> mc.setScreen(new GenericScreen(tuning(t), true));
            case "id", "lic", "card" -> mc.setScreen(new GenericScreen(doc(kind, t), false));
            default -> { }
        }
    }

    static CompoundTag mk(String title) {
        CompoundTag t = new CompoundTag();
        t.putString("title", title);
        t.put("items", new ListTag());
        return t;
    }

    static void line(CompoundTag t, String s) {
        CompoundTag c = new CompoundTag();
        c.putString("t", "l"); c.putString("s", s);
        t.getList("items", Tag.TAG_COMPOUND).add(c);
    }

    static void btn(CompoundTag t, String label, String act, CompoundTag d) {
        CompoundTag c = new CompoundTag();
        c.putString("t", "b"); c.putString("s", label); c.putString("a", act); c.put("d", d);
        t.getList("items", Tag.TAG_COMPOUND).add(c);
    }

    static CompoundTag phone() {
        CompoundTag t = mk("§bTelefon MoonCity");
        String[][] apps = {{"Bancă", "bank"}, {"MoonTaxi", "taxi"}, {"Contacte & SMS", "contacts"}, {"Joburi", "jobs"}, {"MoonNews", "news"},
            {"Primărie", "gov"}, {"Teritorii", "terr"}, {"Reputație", "rep"}, {"Medic", "med"}, {"Contracte", "ctr"}, {"Hartă", "map"}, {"Setări", "settings"}};
        for (String[] a : apps) {
            CompoundTag d = new CompoundTag();
            d.putString("a", a[1]);
            btn(t, a[0], "phone:app", d);
        }
        return t;
    }

    static CompoundTag doc(String kind, CompoundTag d) {
        String title = switch (kind) {
            case "id" -> "§9ROMÂNIA - CARTE DE IDENTITATE";
            case "lic" -> "§6ROMÂNIA - PERMIS DE CONDUCERE";
            default -> "§bMOONBANK - CARD";
        };
        CompoundTag t = mk(title);
        line(t, "§7Nume: §f" + d.getString("name") + "   §7ID: §f" + d.getInt("pid"));
        if (kind.equals("id")) {
            line(t, "§7CNP: §f" + d.getString("cnp"));
            line(t, "§7Născut: §f" + d.getString("born") + "  §7Sex: §f" + (d.getBoolean("male") ? "M" : "F"));
            line(t, "§7Domiciliu: §f" + d.getString("addr"));
            line(t, "§7Seria: §f" + d.getString("series"));
        } else if (kind.equals("lic")) {
            line(t, "§7Născut: §f" + d.getString("born"));
            line(t, "§7Categoria: §f" + d.getString("cat"));
        } else {
            line(t, "§7IBAN: §f" + d.getString("iban"));
        }
        if (d.contains("issued")) line(t, "§7Emis: §f" + d.getString("issued") + "  §7Expiră: §f" + d.getString("exp"));
        return t;
    }

    /** Panou tuning, in dreapta ecranului (stil FiveM): statistici + optiuni pe categorii. */
    static CompoundTag tuning(CompoundTag in) {
        CompoundTag t = mk("§6MoonTuning - " + in.getString("veh"));
        line(t, "§7Sold: §a" + in.getLong("bank") + " RON");
        line(t, "§cViteză " + in.getInt("spd") + " §9Accel " + in.getInt("acc") + " §aManevr. " + in.getInt("hnd") + " §eFrână " + in.getInt("brk") + " §bModif " + in.getInt("mod"));
        String[] cats = {"Motor", "Roți", "Culoare", "ECU / Stage"};
        ListTag o = in.getList("opts", Tag.TAG_COMPOUND);
        for (int c = 0; c < 4; c++) {
            boolean head = false;
            for (int i = 0; i < o.size(); i++) {
                CompoundTag x = o.getCompound(i);
                if (x.getInt("cat") != c) continue;
                if (!head) { line(t, "§e§l" + cats[c]); head = true; }
                CompoundTag d = new CompoundTag();
                d.putLong("pos", in.getLong("pos"));
                d.putString("id", x.getString("id"));
                btn(t, x.getString("name") + " - " + x.getLong("price") + " RON", "tune:buy", d);
            }
        }
        return t;
    }

    public static void send(String act, CompoundTag d) { Net.toServer(act, d); }
}
