package ro.mooncity.x.client;

import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import ro.mooncity.x.MoonX;

/** HUD MoonCity: harta + bare viata/armura/foame/sete (jos-stanga, ca in video). */
public class Hud {
    static final ResourceLocation ARROW = new ResourceLocation(MoonX.ID, "textures/misc/arrow.png");
    static final ResourceLocation BADGE = new ResourceLocation(MoonX.ID, "textures/misc/garage_badge.png");
    static final ResourceLocation[] IC = {
        new ResourceLocation(MoonX.ID, "textures/misc/ic_heart.png"), new ResourceLocation(MoonX.ID, "textures/misc/ic_shield.png"),
        new ResourceLocation(MoonX.ID, "textures/misc/ic_food.png"), new ResourceLocation(MoonX.ID, "textures/misc/ic_drop.png")};
    static final int[] COL = {0xFFFF4D5E, 0xFF5AA9FF, 0xFFFFA43A, 0xFF35D6FF, 0xFFB08CFF};

    public static void render(GuiGraphics g, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        var pl = mc.player;
        var f = mc.font;
        int S = 88, x = 8, rows = 5;
        int panelH = rows * 11 + 4, py = h - 8 - panelH, my = py - 14 - S;

        // ---- harta ----
        g.fill(x - 2, my - 2, x + S + 2, my + S + 2, 0xFF6A3DF0);
        g.fill(x - 1, my - 1, x + S + 1, my + S + 1, 0xFF0B0714);
        if (Minimap.ready()) g.blit(Minimap.LOC, x, my, S, S, 0, 0, 64, 64, 64, 64);
        g.pose().pushPose();
        g.pose().translate(x + S / 2f, my + S / 2f, 0);
        g.pose().mulPose(Axis.ZP.rotationDegrees(pl.getYRot() - 180f));
        g.blit(ARROW, -6, -6, 12, 12, 0, 0, 24, 24, 24, 24);
        g.pose().popPose();
        g.blit(BADGE, x + 2, my + 2, 13, 13, 0, 0, 256, 256, 256, 256);
        g.drawString(f, "N", x + S / 2 - 2, my + 2, 0xFFFFFFFF, true);
        g.drawString(f, "§7X §f" + pl.getBlockX() + " §7Z §f" + pl.getBlockZ(), x, my + S + 4, 0xFFFFFFFF, false);

        // ---- bare ----
        float[] v = {
            pl.getHealth() / Math.max(1f, pl.getMaxHealth()),
            Math.min(1f, pl.getArmorValue() / 20f),
            pl.getFoodData().getFoodLevel() / 20f,
            ClientHooks.thirst / 100f,
            ClientHooks.kg / Math.max(1f, ClientHooks.kgMax)};
        g.fill(x - 2, py - 2, x + S + 2, py + panelH - 2, 0xB00B0714);
        for (int i = 0; i < rows; i++) {
            int ry = py + i * 11;
            if (i < 4) g.blit(IC[i], x, ry, 9, 9, 0, 0, 9, 9, 9, 9);
            else g.drawString(f, "§lKG", x, ry + 1, 0xFFFFFFFF, true);
            int xo = i < 4 ? 13 : 15;
            int col = i == 4 && v[i] > 1f ? 0xFFFF3030 : COL[i];
            g.fill(x + xo, ry + 2, x + xo + 52, ry + 8, 0xFF1B1530);
            g.fill(x + xo, ry + 2, x + xo + Math.round(52 * Math.max(0f, Math.min(1f, v[i]))), ry + 8, col);
            String tx = i < 4 ? Math.round(v[i] * 100) + "" : String.format(java.util.Locale.ROOT, "%.1f/%d", ClientHooks.kg, (int) ClientHooks.kgMax);
            g.drawString(f, tx, x + xo + 56, ry + 1, 0xFFFFFFFF, true);
        }
    }
}
