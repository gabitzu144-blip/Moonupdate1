package ro.mooncity.x.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;
import ro.mooncity.x.Cfg;
import ro.mooncity.x.Veh;

/** Vitezometru + combustibil (desenat cu patrate mici, fara texturi - usor pentru FPS). Apare doar intr-un vehicul MrCrayfish. */
public class Speedo {
    static float smooth, fuelS;
    static final int N = 44, FN = 22;

    public static void render(GuiGraphics g, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        Entity v = mc.player.getVehicle();
        if (v == null || !Veh.powered(v)) { smooth = 0; return; }

        float kmh = (float) Math.abs(Veh.kmh(v));
        smooth += (kmh - smooth) * 0.25f;
        float cap = Veh.cap(v), fu = Veh.fuel(v);
        float fr = cap > 0 ? Math.max(0f, Math.min(1f, fu / cap)) : 0f;
        fuelS += (fr - fuelS) * 0.1f;

        float max = Math.max(60, Cfg.I.hudMaxKmh);
        float frac = Math.min(1f, smooth / max);
        int cx = w - 100, cy = h - 62, r = 46;

        arc(g, cx, cy, r, N, frac, 0xFF1AD6FF, 0xFFFF3B4D, 0.8f, 0x66808080);

        // viteza (scalata x2)
        g.pose().pushPose();
        g.pose().scale(2f, 2f, 1f);
        String s = Integer.toString(Math.round(smooth));
        g.drawString(mc.font, s, (int) (cx / 2f - mc.font.width(s) / 2f), (int) ((cy - 10) / 2f), 0xFFFFFF, true);
        g.pose().popPose();
        g.drawCenteredString(mc.font, "KM/H", cx, cy + 8, 0xFF9FE8FF);
        g.drawCenteredString(mc.font, smooth < 1f ? "N" : "D", cx, cy + 20, 0xFF1AD6FF);

        // combustibil
        int fx = cx - r - 34, fy = cy + 22, fr2 = 20;
        int col = fuelS < 0.15f ? 0xFFFF3B4D : 0xFFFFC21A;
        arc(g, fx, fy, fr2, FN, fuelS, col, col, 2f, 0x66808080);
        g.drawCenteredString(mc.font, "FUEL", fx, fy - 10, 0xFF9FE8FF);
        g.drawCenteredString(mc.font, Math.round(fuelS * 100) + "%", fx, fy, col);
    }

    /** Arc de 270 grade (de la stanga-jos, in sens orar), cu 'n' segmente. Segmentele peste 'redFrom' sunt rosii. */
    static void arc(GuiGraphics g, int cx, int cy, int r, int n, float frac, int on, int red, float redFrom, int off) {
        for (int i = 0; i < n; i++) {
            float t = i / (float) (n - 1);
            double a = Math.toRadians(135 + 270 * t);
            int x = cx + (int) Math.round(Math.cos(a) * r), y = cy + (int) Math.round(Math.sin(a) * r);
            int c = t <= frac ? (t > redFrom ? red : on) : off;
            g.fill(x - 1, y - 1, x + 2, y + 2, c);
        }
    }
}
