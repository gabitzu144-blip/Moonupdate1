package ro.mooncity.x.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.state.BlockState;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import ro.mooncity.x.MoonX;
import ro.mooncity.x.block.MarkerBE;
import ro.mooncity.x.block.MarkerBlock;

/** Garaj: disc verde pe jos (pulseaza), badge cu logo Moon care pluteste si eticheta deasupra. Doar 2 quad-uri + text. */
public class MarkerRenderer implements BlockEntityRenderer<MarkerBE> {
    static final ResourceLocation DISC = new ResourceLocation(MoonX.ID, "textures/misc/garage_disc.png");
    static final ResourceLocation BADGE = new ResourceLocation(MoonX.ID, "textures/misc/garage_badge.png");
    static final int FULL = 0xF000F0;

    final Font font;

    public MarkerRenderer(BlockEntityRendererProvider.Context ctx) { this.font = ctx.getFont(); }

    @Override
    public void render(MarkerBE be, float pt, PoseStack ps, MultiBufferSource buf, int light, int overlay) {
        BlockState st = be.getBlockState();
        if (!(st.getBlock() instanceof MarkerBlock mb)) return;
        float time = (be.getLevel() == null ? 0 : be.getLevel().getGameTime()) + pt;

        // ---- disc pe jos ----
        float r = (float) MarkerBE.R;
        int a = 190 + (int) (65 * Math.sin(time / 12f)) / 1;
        a = Math.max(120, Math.min(255, a));
        ps.pushPose();
        ps.translate(0.5, 0.02, 0.5);
        quadFlat(buf.getBuffer(RenderType.entityTranslucentEmissive(DISC)), ps, r, a);
        ps.popPose();

        // ---- logo plutitor, orientat spre camera ----
        float bob = (float) Math.sin(time / 14f) * 0.08f;
        ps.pushPose();
        ps.translate(0.5, 3.3 + bob, 0.5);
        ps.mulPose(Minecraft.getInstance().getEntityRenderDispatcher().cameraOrientation());
        quadBillboard(buf.getBuffer(RenderType.entityTranslucentEmissive(BADGE)), ps, 0.55f);

        // ---- eticheta ----
        ps.translate(0, -0.75, 0);
        ps.scale(-0.03f, -0.03f, 0.03f);
        float w = font.width(mb.label);
        font.drawInBatch(mb.label, -w / 2f, 0, 0xFFFFFFFF, true, ps.last().pose(), buf, Font.DisplayMode.NORMAL, 0, FULL);
        ps.popPose();
    }

    static void quadFlat(VertexConsumer vc, PoseStack ps, float r, int alpha) {
        Matrix4f m = ps.last().pose();
        Matrix3f n = ps.last().normal();
        v(vc, m, n, -r, 0, -r, 0, 0, alpha, 0, 1, 0);
        v(vc, m, n, -r, 0, r, 0, 1, alpha, 0, 1, 0);
        v(vc, m, n, r, 0, r, 1, 1, alpha, 0, 1, 0);
        v(vc, m, n, r, 0, -r, 1, 0, alpha, 0, 1, 0);
    }

    static void quadBillboard(VertexConsumer vc, PoseStack ps, float s) {
        Matrix4f m = ps.last().pose();
        Matrix3f n = ps.last().normal();
        v(vc, m, n, -s, -s, 0, 0, 1, 255, 0, 0, 1);
        v(vc, m, n, s, -s, 0, 1, 1, 255, 0, 0, 1);
        v(vc, m, n, s, s, 0, 1, 0, 255, 0, 0, 1);
        v(vc, m, n, -s, s, 0, 0, 0, 255, 0, 0, 1);
    }

    static void v(VertexConsumer vc, Matrix4f m, Matrix3f n, float x, float y, float z, float u, float vv, int a, float nx, float ny, float nz) {
        vc.vertex(m, x, y, z).color(255, 255, 255, a).uv(u, vv).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(FULL).normal(n, nx, ny, nz).endVertex();
    }

    @Override public int getViewDistance() { return 48; }
}
