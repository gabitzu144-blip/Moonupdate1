package ro.mooncity.x.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import ro.mooncity.x.MoonX;

/** Fascicul de lumina + cerc pe jos la destinatia contractului activ. */
@Mod.EventBusSubscriber(modid = MoonX.ID, value = Dist.CLIENT)
public class NavRenderer {
    static final ResourceLocation BEAM = new ResourceLocation(MoonX.ID, "textures/misc/beam.png");
    static final ResourceLocation RING = new ResourceLocation(MoonX.ID, "textures/misc/garage_disc.png");

    @SubscribeEvent
    public static void level(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS || !ClientHooks.navOn) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        Vec3 cam = e.getCamera().getPosition();
        int bx = ClientHooks.navX, bz = ClientHooks.navZ;
        double gy = mc.level.hasChunkAt(new BlockPos(bx, 64, bz))
            ? mc.level.getHeight(Heightmap.Types.MOTION_BLOCKING, bx, bz) : mc.player.getY();
        PoseStack ps = e.getPoseStack();
        MultiBufferSource.BufferSource bs = mc.renderBuffers().bufferSource();
        RenderType ringRt = RenderType.entityTranslucentEmissive(RING);
        RenderType beamRt = RenderType.entityTranslucentEmissive(BEAM);

        ps.pushPose();
        ps.translate(bx + 0.5 - cam.x, gy - cam.y + 0.05, bz + 0.5 - cam.z);
        MarkerRenderer.quadFlat(bs.getBuffer(ringRt), ps, 8f, 200);
        VertexConsumer vc = bs.getBuffer(beamRt);
        Matrix4f m = ps.last().pose();
        Matrix3f n = ps.last().normal();
        float r = 0.7f, hgt = 220f;
        vert(vc, m, n, -r, 0, hgt);
        vert(vc, m, n, 0, -r, hgt);
        ps.popPose();
        bs.endBatch(ringRt);
        bs.endBatch(beamRt);
    }

    /** Doua pereti verticali incrucisati (X si Z). */
    static void vert(VertexConsumer vc, Matrix4f m, Matrix3f n, float ax, float az, float h) {
        float bx = -ax, bz = -az;
        MarkerRenderer.v(vc, m, n, ax, 0, az, 0, 1, 255, 0, 0, 1);
        MarkerRenderer.v(vc, m, n, bx, 0, bz, 1, 1, 255, 0, 0, 1);
        MarkerRenderer.v(vc, m, n, bx, h, bz, 1, 0, 255, 0, 0, 1);
        MarkerRenderer.v(vc, m, n, ax, h, az, 0, 0, 255, 0, 0, 1);
    }
}
