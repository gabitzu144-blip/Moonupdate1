package ro.mooncity.x.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import ro.mooncity.x.Net;

import java.util.*;

/** Un singur ecran care afiseaza orice meniu (linii, butoane, campuri) trimis de server. */
public class GenericScreen extends Screen {
    final CompoundTag data;
    final boolean right;
    final Map<String, String> vals = new HashMap<>();
    int scroll, pw, px, py, ph, contentH;

    public GenericScreen(CompoundTag data, boolean right) {
        super(Component.literal(data.getString("title")));
        this.data = data;
        this.right = right;
    }

    @Override
    protected void init() {
        pw = Math.min(320, width - 20);
        px = right ? width - pw - 10 : (width - pw) / 2;
        py = 12;
        ph = height - 24;
        var items = data.getList("items", Tag.TAG_COMPOUND);
        int y = py + 28 - scroll;
        int top = py + 24, bot = py + ph - 4;
        for (int i = 0; i < items.size(); i++) {
            CompoundTag c = items.getCompound(i);
            switch (c.getString("t")) {
                case "l" -> y += Math.max(1, font.split(Component.literal(c.getString("s")), pw - 16).size()) * 10 + 2;
                case "b" -> {
                    if (y >= top && y + 20 <= bot) {
                        String act = c.getString("a");
                        CompoundTag d = c.getCompound("d");
                        addRenderableWidget(Button.builder(Component.literal(c.getString("s")), b -> fire(act, d)).bounds(px + 8, y, pw - 16, 20).build());
                    }
                    y += 23;
                }
                case "i" -> {
                    String k = c.getString("k");
                    if (y >= top && y + 32 <= bot) {
                        EditBox eb = new EditBox(font, px + 8, y + 10, pw - 16, 16, Component.literal(c.getString("s")));
                        eb.setMaxLength(120);
                        eb.setValue(vals.computeIfAbsent(k, kk -> c.getString("v")));
                        eb.setResponder(v -> vals.put(k, v));
                        addRenderableWidget(eb);
                    }
                    y += 32;
                }
                default -> { }
            }
        }
        contentH = y + scroll - (py + 28);
    }

    void fire(String act, CompoundTag d) {
        CompoundTag out = d.copy();
        vals.forEach(out::putString);
        Net.toServer(act, out);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        int max = Math.max(0, contentH - (ph - 40));
        int ns = Math.max(0, Math.min(max, scroll - (int) (delta * 22)));
        if (ns != scroll) { scroll = ns; rebuildWidgets(); }
        return true;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        g.fill(px, py, px + pw, py + ph, 0xE0101018);
        g.fill(px, py, px + pw, py + 22, 0xFF4B2BC0);
        g.drawString(font, title, px + 8, py + 7, 0xFFFFFF);
        g.enableScissor(px, py + 24, px + pw, py + ph - 4);
        var items = data.getList("items", Tag.TAG_COMPOUND);
        int y = py + 28 - scroll;
        for (int i = 0; i < items.size(); i++) {
            CompoundTag c = items.getCompound(i);
            switch (c.getString("t")) {
                case "l" -> {
                    List<FormattedCharSequence> ls = font.split(Component.literal(c.getString("s")), pw - 16);
                    for (FormattedCharSequence s : ls) { g.drawString(font, s, px + 8, y, 0xFFFFFF); y += 10; }
                    if (ls.isEmpty()) y += 10;
                    y += 2;
                }
                case "b" -> y += 23;
                case "i" -> { g.drawString(font, c.getString("s"), px + 8, y, 0xAAAAAA); y += 32; }
                default -> { }
            }
        }
        g.disableScissor();
        super.render(g, mx, my, pt);
    }

    @Override public boolean isPauseScreen() { return false; }
}
