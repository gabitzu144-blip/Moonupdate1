package ro.mooncity.x.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

/** Buton in stilul MoonCity (mov, colturi drepte, bara luminoasa pe stanga la hover). */
public class MoonButton extends Button {
    public MoonButton(int x, int y, int w, int h, Component msg, OnPress press) {
        super(x, y, w, h, msg, press, DEFAULT_NARRATION);
    }

    @Override
    protected void renderWidget(GuiGraphics g, int mx, int my, float pt) {
        boolean hov = isHoveredOrFocused();
        int x = getX(), y = getY(), w = getWidth(), h = getHeight();
        g.fillGradient(x, y, x + w, y + h, hov ? 0xFF5B3BD0 : 0xFF241A4A, hov ? 0xFF3B1FA8 : 0xFF171030);
        g.fill(x, y, x + 2, y + h, hov ? 0xFF9F7BFF : 0xFF6A3DF0);
        var f = net.minecraft.client.Minecraft.getInstance().font;
        g.drawCenteredString(f, getMessage(), x + w / 2 + 1, y + (h - 8) / 2, active ? 0xFFFFFFFF : 0xFF888888);
    }
}
