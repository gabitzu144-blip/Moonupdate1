package ro.mooncity.x.client;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.levelgen.Heightmap;
import ro.mooncity.x.MoonX;

/** Harta de sus in jos, 1 pixel = 2 blocuri, actualizata o data pe secunda intr-o textura (ieftin pentru FPS). */
public class Minimap {
    public static final ResourceLocation LOC = new ResourceLocation(MoonX.ID, "minimap_dyn");
    static final int N = 64, STEP = 2;
    static DynamicTexture tex;
    static int c;

    public static boolean ready() { return tex != null; }

    public static void tick(Minecraft mc) {
        if (mc.level == null || mc.player == null || mc.isPaused()) return;
        if (++c % 20 != 0) return;
        if (tex == null) {
            tex = new DynamicTexture(N, N, false);
            mc.getTextureManager().register(LOC, tex);
        }
        NativeImage img = tex.getPixels();
        if (img == null) return;
        int px = mc.player.getBlockX(), pz = mc.player.getBlockZ();
        int[][] hs = new int[N][N];
        int[][] col = new int[N][N];
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                int wx = px + (i - N / 2) * STEP, wz = pz + (j - N / 2) * STEP;
                LevelChunk ch = mc.level.getChunkSource().getChunkNow(wx >> 4, wz >> 4);
                if (ch == null) { col[i][j] = 0x0B0714; continue; }
                int y = ch.getHeight(Heightmap.Types.WORLD_SURFACE, wx & 15, wz & 15);
                mp.set(wx, Math.max(mc.level.getMinBuildHeight(), y - 1), wz);
                BlockState st = ch.getBlockState(mp);
                int rgb = st.getMapColor(mc.level, mp).col;
                col[i][j] = rgb == 0 ? 0x0B0714 : rgb;
                hs[i][j] = y;
            }
        }
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                int rgb = col[i][j];
                float f = 1f;
                if (i > 0 && j > 0 && rgb != 0x0B0714) {
                    int d = hs[i][j] - hs[i - 1][j - 1];
                    f = d > 0 ? 1.15f : d < 0 ? 0.82f : 1f;
                }
                int r = Math.min(255, (int) (((rgb >> 16) & 255) * f)), g = Math.min(255, (int) (((rgb >> 8) & 255) * f)), b = Math.min(255, (int) ((rgb & 255) * f));
                img.setPixelRGBA(i, j, 0xFF000000 | (b << 16) | (g << 8) | r);
            }
        }
        tex.upload();
    }
}
