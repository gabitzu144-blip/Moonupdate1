package ro.mooncity.x.client;

import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import ro.mooncity.x.MoonX;

/** Ascunde viata/armura/foamea vanilla (le inlocuim) si muta chatul sus-stanga. */
@Mod.EventBusSubscriber(modid = MoonX.ID, value = Dist.CLIENT)
public class HudEvents {
    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase == TickEvent.Phase.END) Minimap.tick(Minecraft.getInstance());
    }

    @SubscribeEvent
    public static void pre(RenderGuiOverlayEvent.Pre e) {
        var o = e.getOverlay();
        if (o == VanillaGuiOverlay.PLAYER_HEALTH.type() || o == VanillaGuiOverlay.ARMOR_LEVEL.type() || o == VanillaGuiOverlay.FOOD_LEVEL.type()) {
            e.setCanceled(true);
        } else if (o == VanillaGuiOverlay.CHAT_PANEL.type()) {
            e.getGuiGraphics().pose().pushPose();
            e.getGuiGraphics().pose().translate(0, -(e.getWindow().getGuiScaledHeight() - 140), 0);
        }
    }

    @SubscribeEvent
    public static void post(RenderGuiOverlayEvent.Post e) {
        if (e.getOverlay() == VanillaGuiOverlay.CHAT_PANEL.type()) e.getGuiGraphics().pose().popPose();
    }
}
