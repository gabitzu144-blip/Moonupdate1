package ro.mooncity.x.client;

import com.mojang.brigadier.Command;
import net.minecraft.client.CloudStatus;
import net.minecraft.client.GraphicsStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.ParticleStatus;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterClientCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import ro.mooncity.x.MoonX;

/** /moonfps = aplica setari video usoare (mult mai multi FPS). /moonfps off = inapoi la valori normale. */
@Mod.EventBusSubscriber(modid = MoonX.ID, value = Dist.CLIENT)
public class FpsMode {
    @SubscribeEvent
    public static void cmds(RegisterClientCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("moonfps")
            .executes(c -> { apply(true); return Command.SINGLE_SUCCESS; })
            .then(Commands.literal("off").executes(c -> { apply(false); return Command.SINGLE_SUCCESS; })));
    }

    static void apply(boolean fast) {
        Minecraft mc = Minecraft.getInstance();
        Options o = mc.options;
        o.graphicsMode().set(fast ? GraphicsStatus.FAST : GraphicsStatus.FANCY);
        o.renderDistance().set(fast ? 8 : 12);
        o.simulationDistance().set(fast ? 6 : 10);
        o.entityDistanceScaling().set(fast ? 0.6 : 1.0);
        o.particles().set(fast ? ParticleStatus.MINIMAL : ParticleStatus.ALL);
        o.ambientOcclusion().set(!fast);
        o.biomeBlendRadius().set(fast ? 0 : 2);
        o.cloudStatus().set(fast ? CloudStatus.OFF : CloudStatus.FANCY);
        o.entityShadows().set(!fast);
        o.enableVsync().set(!fast);
        o.save();
        if (mc.levelRenderer != null) mc.levelRenderer.allChanged();
        if (mc.player != null) mc.player.sendSystemMessage(Component.literal(fast ? "§aMod FPS activat (grafică rapidă, 8 chunk-uri)." : "§eSetări video readuse la normal."));
    }
}
