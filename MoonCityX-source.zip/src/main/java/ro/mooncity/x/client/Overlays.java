package ro.mooncity.x.client;

import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import ro.mooncity.x.MoonX;

/** Toast-uri MoonBank (dreapta-sus) + busola spre destinatia contractului (sus-centru). */
public class Overlays {
    static final ResourceLocation ARROW = new ResourceLocation(MoonX.ID, "textures/misc/arrow.png");

    public static void render(GuiGraphics g, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        var f = mc.font;

        // ---- toast-uri ----
        long now = System.currentTimeMillis();
        ClientHooks.TOASTS.removeIf(t -> t.until() < now);
        int y = 8;
        for (ClientHooks.Toast t : ClientHooks.TOASTS) {
            int tw = Math.max(130, f.width(t.text()) + 34);
            int x = w - tw - 8;
            g.fill(x, y, x + tw, y + 24, 0xCC101018);
            g.fill(x, y, x + 3, y + 24, 0xFF000000 | t.color());
            g.blit(Hud.BADGE, x + 6, y + 5, 14, 14, 0, 0, 256, 256, 256, 256);
            g.drawString(f, t.title(), x + 24, y + 3, 0xFF000000 | t.color(), false);
            g.drawString(f, t.text(), x + 24, y + 13, 0xFFFFFFFF, false);
            y += 27;
        }

        // ---- busola + distanta ----
        if (ClientHooks.navOn) {
            double dx = ClientHooks.navX + 0.5 - mc.player.getX(), dz = ClientHooks.navZ + 0.5 - mc.player.getZ();
            float bearing = (float) Math.toDegrees(Math.atan2(-dx, dz));
            float rel = Mth.wrapDegrees(bearing - mc.player.getYRot());
            int dist = (int) Math.round(Math.sqrt(dx * dx + dz * dz));
            int cx = w / 2, cy = 30;
            g.pose().pushPose();
            g.pose().translate(cx, cy, 0);
            g.pose().mulPose(Axis.ZP.rotationDegrees(rel));
            g.blit(ARROW, -12, -12, 0, 0, 24, 24, 24, 24);
            g.pose().popPose();
            g.drawCenteredString(f, dist + " m", cx, cy + 16, 0xFFFFFFFF);
            String lab = ClientHooks.navLabel;
            if (!lab.isEmpty()) g.drawCenteredString(f, lab, cx, cy + 27, 0xFFFFC21A);
        }
    }
}
