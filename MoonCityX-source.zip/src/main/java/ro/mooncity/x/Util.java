package ro.mooncity.x;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class Util {
    public static String fmt(long v) {
        return String.format(Locale.ROOT, "%,d", v).replace(',', '.') + " RON";
    }

    /** Citeste un numar dintr-un tag, indiferent daca e String sau numar. */
    public static long num(CompoundTag d, String k) {
        if (d == null || !d.contains(k)) return 0;
        if (d.contains(k, Tag.TAG_STRING)) {
            try { return (long) Double.parseDouble(d.getString(k).trim().replace(",", ".")); } catch (Exception e) { return 0; }
        }
        return d.getLong(k);
    }

    public static String str(CompoundTag d, String k) { return d.getString(k).trim(); }

    public static void msg(ServerPlayer p, String s) { p.sendSystemMessage(Component.literal("§8[§dMoon§8] §r" + s)); }

    public static void bar(ServerPlayer p, String s) { p.displayClientMessage(Component.literal(s), true); }

    public static ServerPlayer online(UUID u) {
        MinecraftServer s = ServerLifecycleHooks.getCurrentServer();
        return s == null ? null : s.getPlayerList().getPlayer(u);
    }

    public static boolean op(ServerPlayer p) { return p.hasPermissions(2); }

    public static void give(ServerPlayer p, ItemStack st) {
        if (!p.getInventory().add(st)) p.drop(st, false);
    }

    public static String key(Item i) {
        ResourceLocation k = ForgeRegistries.ITEMS.getKey(i);
        return k == null ? "minecraft:air" : k.toString();
    }

    public static Item item(String id) {
        Item i = ForgeRegistries.ITEMS.getValue(new ResourceLocation(id));
        return i;
    }

    public static int count(ServerPlayer p, String id) {
        int n = 0;
        for (int i = 0; i < p.getInventory().getContainerSize(); i++) {
            ItemStack s = p.getInventory().getItem(i);
            if (!s.isEmpty() && key(s.getItem()).equals(id)) n += s.getCount();
        }
        return n;
    }

    public static int remove(ServerPlayer p, String id, int amount) {
        int left = amount;
        for (int i = 0; i < p.getInventory().getContainerSize() && left > 0; i++) {
            ItemStack s = p.getInventory().getItem(i);
            if (!s.isEmpty() && key(s.getItem()).equals(id)) {
                int t = Math.min(left, s.getCount());
                s.shrink(t);
                left -= t;
            }
        }
        return amount - left;
    }

    public static String pos(BlockPos p) { return p.getX() + "," + p.getY() + "," + p.getZ(); }

    public static String posKey(ServerLevel l, BlockPos p) { return l.dimension().location() + "|" + p.getX() + "," + p.getY() + "," + p.getZ(); }

    public static String hm(long ms) {
        long s = ms / 1000;
        return (s / 60) + "m " + (s % 60) + "s";
    }

    // ---------------- vehicule ----------------
    public static boolean isVehicle(Entity e) {
        ResourceLocation k = ForgeRegistries.ENTITY_TYPES.getKey(e.getType());
        return k != null && Cfg.I.vehicleNamespaces.contains(k.getNamespace());
    }

    /** Vehiculul in care sta jucatorul sau cel mai apropiat (in raza). */
    public static Entity nearestVehicle(ServerPlayer p, double r) {
        Entity v = p.getVehicle();
        if (v != null && isVehicle(v)) return v;
        List<Entity> l = p.level().getEntities(p, p.getBoundingBox().inflate(r), Util::isVehicle);
        return l.stream().min(Comparator.comparingDouble(e -> e.distanceToSqr(p))).orElse(null);
    }

    public static Entity nearestVehicleAt(ServerLevel l, BlockPos c, double r) {
        List<Entity> li = l.getEntities((Entity) null, new AABB(c).inflate(r), Util::isVehicle);
        return li.stream().min(Comparator.comparingDouble(e -> e.distanceToSqr(c.getX() + .5, c.getY(), c.getZ() + .5))).orElse(null);
    }

    public static UUID owner(Entity e) {
        String s = e.getPersistentData().getString("moon_owner");
        try { return s.isEmpty() ? null : UUID.fromString(s); } catch (Exception ex) { return null; }
    }
}
