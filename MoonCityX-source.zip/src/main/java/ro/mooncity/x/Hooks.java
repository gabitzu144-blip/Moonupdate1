package ro.mooncity.x;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import ro.mooncity.x.feat.Fuel;
import ro.mooncity.x.feat.Shops;

/** Notificari de plasare/stergere blocuri generice. */
public class Hooks {
    public static void placed(String act, Level l, BlockPos p) {
        if (!(l instanceof ServerLevel sl)) return;
        if (act.startsWith("fuel:")) Fuel.register(sl, p);
    }

    public static void removed(String act, Level l, BlockPos p) {
        if (!(l instanceof ServerLevel sl)) return;
        if (act.startsWith("fuel:")) Fuel.unregister(sl, p);
        if (act.startsWith("shop:")) Shops.removed(sl, p);
    }
}
