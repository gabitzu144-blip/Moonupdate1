package ro.mooncity.x.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.phys.BlockHitResult;
import ro.mooncity.x.Actions;
import ro.mooncity.x.Hooks;

/** Bloc generic: click dreapta => actiune pe server (meniu). Are directie (FACING) pentru garaj etc. */
public class ActBlock extends HorizontalDirectionalBlock {
    final String act;

    public ActBlock(Properties p, String act) {
        super(p);
        this.act = act;
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) { b.add(FACING); }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext c) {
        return defaultBlockState().setValue(FACING, c.getHorizontalDirection().getOpposite());
    }

    @Override
    public InteractionResult use(BlockState s, Level l, BlockPos pos, Player pl, InteractionHand h, BlockHitResult hit) {
        if (!l.isClientSide && pl instanceof ServerPlayer sp) {
            CompoundTag d = new CompoundTag();
            d.putLong("pos", pos.asLong());
            Actions.handle(sp, act, d);
        }
        return InteractionResult.sidedSuccess(l.isClientSide);
    }

    @Override
    public void onPlace(BlockState s, Level l, BlockPos p, BlockState old, boolean moving) {
        if (!l.isClientSide) Hooks.placed(act, l, p);
    }

    @Override
    public void onRemove(BlockState s, Level l, BlockPos p, BlockState n, boolean moving) {
        if (!l.isClientSide && !s.is(n.getBlock())) Hooks.removed(act, l, p);
        super.onRemove(s, l, p, n, moving);
    }
}
