package ro.mooncity.x.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import ro.mooncity.x.Reg;

public class MarkerBE extends BlockEntity {
    public static final double R = 6.0;

    public MarkerBE(BlockPos pos, BlockState st) { super(Reg.MARKER_BE.get(), pos, st); }

    /** Cercul si logoul ies din cubul blocului: largim caseta de randare ca sa nu dispara cand blocul e doar pe margine. */
    @Override
    public AABB getRenderBoundingBox() {
        return new AABB(worldPosition).inflate(R, 3.5, R);
    }
}
