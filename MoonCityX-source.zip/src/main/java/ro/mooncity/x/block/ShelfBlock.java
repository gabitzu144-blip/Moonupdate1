package ro.mooncity.x.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import ro.mooncity.x.feat.Shops;

/** Raft de magazin. Se ia din creative. Click cu item in mana (proprietar) = alege produsul; click gol = cumperi. */
public class ShelfBlock extends HorizontalDirectionalBlock implements EntityBlock {
    static final VoxelShape N = Block.box(0, 0, 8, 16, 16, 16);
    static final VoxelShape S = Block.box(0, 0, 0, 16, 16, 8);
    static final VoxelShape E = Block.box(0, 0, 0, 8, 16, 16);
    static final VoxelShape W = Block.box(8, 0, 0, 16, 16, 16);

    public ShelfBlock(Properties p) {
        super(p);
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) { b.add(FACING); }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext c) {
        return defaultBlockState().setValue(FACING, c.getHorizontalDirection().getOpposite());
    }

    @Override
    public VoxelShape getShape(BlockState s, BlockGetter g, BlockPos p, CollisionContext c) {
        return switch (s.getValue(FACING)) {
            case SOUTH -> S;
            case EAST -> E;
            case WEST -> W;
            default -> N;
        };
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState st) { return new ShelfBE(pos, st); }

    @Override
    public InteractionResult use(BlockState s, Level l, BlockPos pos, Player pl, InteractionHand h, BlockHitResult hit) {
        if (!l.isClientSide && pl instanceof ServerPlayer sp && l.getBlockEntity(pos) instanceof ShelfBE be) {
            Shops.shelfUse(sp, be, pos, h);
        }
        return InteractionResult.sidedSuccess(l.isClientSide);
    }
}
