package ro.mooncity.x.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Bloc de actiune cu marker vizual (cerc pe jos + logo Moon plutitor + eticheta). Doar garajul il foloseste acum. */
public class MarkerBlock extends ActBlock implements EntityBlock {
    public final String label;

    public MarkerBlock(Properties p, String act, String label) {
        super(p, act);
        this.label = label;
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState st) { return new MarkerBE(pos, st); }
}
