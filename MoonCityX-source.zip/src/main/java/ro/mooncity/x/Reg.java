package ro.mooncity.x;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import ro.mooncity.x.block.ActBlock;
import ro.mooncity.x.block.MarkerBE;
import ro.mooncity.x.block.MarkerBlock;
import ro.mooncity.x.block.ShelfBE;
import ro.mooncity.x.block.ShelfBlock;
import ro.mooncity.x.item.*;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

public class Reg {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MoonX.ID);
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MoonX.ID);
    public static final DeferredRegister<BlockEntityType<?>> BES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, MoonX.ID);
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MoonX.ID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MoonX.ID);

    public static final List<RegistryObject<Item>> TAB_ITEMS = new ArrayList<>();
    public static final String[] ROLES = {"seller", "banker", "jobs", "driving", "casino", "black", "medic", "city", "taxi", "news", "depozit"};

    static RegistryObject<Item> item(String id, Supplier<Item> s) {
        RegistryObject<Item> o = ITEMS.register(id, s);
        TAB_ITEMS.add(o);
        return o;
    }

    static RegistryObject<Block> block(String id, Supplier<Block> b) {
        RegistryObject<Block> o = BLOCKS.register(id, b);
        TAB_ITEMS.add(ITEMS.register(id, () -> new BlockItem(o.get(), new Item.Properties())));
        return o;
    }

    static BlockBehaviour.Properties props() { return BlockBehaviour.Properties.of().strength(3f, 6f).sound(SoundType.METAL); }

    // ---- iteme ----
    public static final RegistryObject<Item> PHONE = item("phone", PhoneItem::new);
    public static final RegistryObject<Item> MDT = item("mdt_tablet", MdtItem::new);
    public static final RegistryObject<Item> BANK_CARD = item("bank_card", () -> new DocItem("card"));
    public static final RegistryObject<Item> ID_CARD = item("id_card", () -> new DocItem("id"));
    public static final RegistryObject<Item> LICENSE = item("license", () -> new DocItem("lic"));
    public static final RegistryObject<Item> MEDKIT = item("medkit", () -> new MedItem(10f, 40));
    public static final RegistryObject<Item> MOONBOX = item("moonbox", () -> new Item(new Item.Properties().stacksTo(8)));
    public static final RegistryObject<Item> BANDAGE = item("bandage", () -> new MedItem(4f, 20));
    public static final Map<Integer, RegistryObject<Item>> MONEY = new LinkedHashMap<>();
    public static final Map<String, RegistryObject<Item>> NPC_ITEMS = new LinkedHashMap<>();

    static {
        for (int v : new int[]{1, 5, 10, 50, 100, 200, 500}) MONEY.put(v, item("bani_" + v, () -> new MoneyItem(v)));
        for (String r : ROLES) NPC_ITEMS.put(r, item("npc_" + r, () -> new NpcSpawnItem(r)));
    }

    // ---- blocuri ----
    public static final RegistryObject<Block> ATM = block("atm", () -> new ActBlock(props(), "bank:atm"));
    public static final RegistryObject<Block> SHOP_CORE = block("shop_core", () -> new ActBlock(props(), "shop:core"));
    public static final RegistryObject<Block> SHELF = block("shelf", () -> new ShelfBlock(props().noOcclusion()));
    public static final RegistryObject<Block> GARAGE = block("garage", () -> new MarkerBlock(props(), "garage:block", "GARAJ"));
    public static final RegistryObject<Block> PUMP = block("fuel_pump", () -> new ActBlock(props(), "fuel:info"));
    public static final RegistryObject<Block> TUNE = block("tune_bay", () -> new ActBlock(props(), "tune:open"));
    public static final RegistryObject<Block> CASINO = block("casino_machine", () -> new ActBlock(props(), "casino:slotsmenu"));
    public static final RegistryObject<Block> BUS = block("bus_stop", () -> new ActBlock(props(), "bus:stop"));
    public static final RegistryObject<Block> PROPERTY = block("property", () -> new ActBlock(props(), "prop:block"));

    public static final RegistryObject<BlockEntityType<ShelfBE>> SHELF_BE =
        BES.register("shelf", () -> BlockEntityType.Builder.of(ShelfBE::new, SHELF.get()).build(null));

    public static final RegistryObject<BlockEntityType<MarkerBE>> MARKER_BE =
        BES.register("marker", () -> BlockEntityType.Builder.of(MarkerBE::new, GARAGE.get()).build(null));

    public static final RegistryObject<EntityType<MoonNpc>> NPC = ENTITIES.register("npc",
        () -> EntityType.Builder.<MoonNpc>of(MoonNpc::new, MobCategory.MISC).sized(0.6f, 1.95f).clientTrackingRange(10).build("npc"));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main",
        () -> CreativeModeTab.builder().title(Component.literal("MoonCity X"))
            .icon(() -> new ItemStack(PHONE.get()))
            .displayItems((p, o) -> { for (RegistryObject<Item> r : TAB_ITEMS) o.accept(r.get()); })
            .build());

    public static void init(IEventBus bus) {
        ITEMS.register(bus);
        BLOCKS.register(bus);
        BES.register(bus);
        ENTITIES.register(bus);
        TABS.register(bus);
        bus.addListener(Reg::attrs);
    }

    static void attrs(EntityAttributeCreationEvent e) {
        e.put(NPC.get(), MoonNpc.attrs());
    }
}
